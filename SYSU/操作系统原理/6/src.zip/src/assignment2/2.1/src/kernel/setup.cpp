#include "asm_utils.h"
#include "interrupt.h"
#include "stdio.h"
#include "program.h"
#include "thread.h"
#include "sync.h"

// 屏幕IO处理器
STDIO stdio;
// 中断管理器
InterruptManager interruptManager;
// 程序管理器
ProgramManager programManager;

int shared_variable;
SpinLock aLock;

int cheese_burger;
char *quote1 = "Quote 1" ; 
char *quote2 = "Quote 2" ; 
char *quote3 = "Quote 3" ; 

void a_mother(void *arg)
{
    aLock.lock();
    int delay = 0;

    printf("mother: start to make cheese burger, there are %d cheese burger now\n", cheese_burger);
    // make 10 cheese_burger
    cheese_burger += 10;

    printf("mother: oh, I have to hang clothes out.\n");
    // hanging clothes out
    delay = 0xfffffff;
    while (delay)
        --delay;
    // done

    printf("mother: Oh, Jesus! There are %d cheese burgers\n", cheese_burger);
    aLock.unlock();
}

void a_naughty_boy(void *arg)
{
    aLock.lock();
    printf("boy   : Look what I found!\n");
    // eat all cheese_burgers out secretly
    cheese_burger -= 10;
    // run away as fast as possible
    aLock.unlock();
}

void readFirstQuote(void *arg) 
{ 
 printf("First Quote: %s\n", quote1); 
} 
 
void readSecondQuote(void *arg) 
{ 
 printf("Second Quote: %s\n", quote2); 
} 
 
void readThirdQuote(void *arg) 
{ 
 printf("Third Quote: %s\n", quote3); 
} 
 
 
void writeThirdQuote(void *arg) 
{ 
 // 写等待时间，大于 RRschedule 的时间片 
 int wait = 0x3f3f3f3f; 
 while(wait) wait--; 
 quote3 = "Quote 3 new"; 
} 


void writeSecondQuote(void *arg) 
{ 
 // 写等待时间，大于 RRschedule 的时间片 
 int wait = 0x3f3f3f3f; 
 while(wait) wait--; 
 quote2 = "Quote 2 new"; 
} 

void first_thread(void *arg) 
{ 
 // 第 1 个线程不可以返回 
 stdio.moveCursor(0); 
 for (int i = 0; i < 25 * 80; ++i) 
 { 
 stdio.print(' '); 
 } 
 stdio.moveCursor(0); 
 
cheese_burger = 0;
    aLock.initialize();

    programManager.executeThread(a_mother, nullptr, "second thread", 1);
    programManager.executeThread(a_naughty_boy, nullptr, "third thread", 1);

 //模拟读错误 
 //创建线程读第 1-3 条记录 
 programManager.executeThread(readFirstQuote, nullptr, "fourth thread", 1); 
 programManager.executeThread(readSecondQuote, nullptr, "fifth thread", 1); 
 programManager.executeThread(readThirdQuote, nullptr, "sixth thread", 1); 
 //创建线程，修改第 2 条和第 3 条记录为较长内容 
 //由于写时间较长，写线程运行时间大于 RRschedule 的 time quantum 
 programManager.executeThread(writeSecondQuote, nullptr, "seventh thread", 1); 
 programManager.executeThread(writeThirdQuote, nullptr, "eighth thread", 1); 
 //创建线程读第 2 条和第 3 条记录 
 //发现没有读到修改后的项，而是输出了初始项 
 programManager.executeThread(readSecondQuote, nullptr, "ninth thread", 1); 
 programManager.executeThread(readThirdQuote, nullptr, "tenth thread", 1); 
 
 asm_halt(); 
} 



extern "C" void setup_kernel()
{

    // 中断管理器
    interruptManager.initialize();
    interruptManager.enableTimeInterrupt();
    interruptManager.setTimeInterrupt((void *)asm_time_interrupt_handler);

    // 输出管理器
    stdio.initialize();

    // 进程/线程管理器
    programManager.initialize();

    // 创建第一个线程
    int pid = programManager.executeThread(first_thread, nullptr, "first thread", 1);
    if (pid == -1)
    {
        printf("can not execute thread\n");
        asm_halt();
    }

    ListItem *item = programManager.readyPrograms.front();
    PCB *firstThread = ListItem2PCB(item, tagInGeneralList);
    firstThread->status = RUNNING;
    programManager.readyPrograms.pop_front();
    programManager.running = firstThread;
    asm_switch_thread(0, firstThread);

    asm_halt();
}
