#include "asm_utils.h"
#include "interrupt.h"
#include "stdio.h"
#include "program.h"
#include "thread.h"
#include "sync.h"

// 屏幕IO处理器
STDIO stdio;
// 中断管理器
InterruptManager interruptManager;
// 程序管理器
ProgramManager programManager;

Semaphore semaphore;

Semaphore chop[5]; 


void philosopher(int left_chop, int right_chop, int index) 
{ 
    for(;;){  
	printf("Philosopher %d thinking.\n", index + 1); 
 
	int wait; 
 
	// 偶数哲学家 
	if (index % 2 == 0) { 
 		chop[left_chop].P(); // 先拿左边的筷子 
		printf("Philosopher %d taking left chopstick %d\n", index + 1, left_chop + 1); 
 
		wait = 0x3f3f3f3f; 
		while(wait) wait--; 
 
 		chop[right_chop].P(); // 再拿右边的筷子 
 		printf("Philosopher %d taking right chopstick %d\n", index + 1, right_chop + 1); 
 
 		wait = 0x3f3f3f3f; 
 		while(wait) wait--; 
 	} 
 	// 奇数哲学家 
 	else { 
 		chop[right_chop].P(); // 先拿右边的筷子 
 		printf("Philosopher %d taking right chopstick %d\n", index + 1, right_chop + 1); 
 
 		wait = 0x3f3f3f3f; 
 		while(wait) wait--; 
 
 		chop[left_chop].P(); // 再拿左边的筷子 
 		printf("Philosopher %d taking left chopstick %d\n", index + 1, left_chop + 1); 
 
 		wait = 0x3f3f3f3f; 
 		while(wait) wait--; 
 	} 
 
 	// 吃饭 
 	printf("Philosopher %d eating with chopsticks %d and %d\n", index + 1, left_chop + 1, right_chop + 1); 
 
 	wait = 0x3f3f3f3f; 
	while(wait)wait--; 
 
 	chop[left_chop].V(); // 放下左边的筷子 
 	chop[right_chop].V(); // 放下右边的筷子 
    } 

} 

void first_philosopher(void *arg) { 
 philosopher(0, 1, 0); 
} 
 
void second_philosopher(void *arg) { 
 philosopher(1, 2, 1); 
} 
 
void third_philosopher(void *arg) { 
 philosopher(2, 3, 2);                                                         
} 
 
void fourth_philosopher(void *arg) { 
 philosopher(3, 4, 3); 
} 
 
void fifth_philosopher(void *arg) { 
 philosopher(4, 0, 4); 
}



void first_thread(void *arg) 
{ 
 // 第 1 个线程不可以返回 
 stdio.moveCursor(0); 
 for (int i = 0; i < 25 * 80; ++i) 
 { 
 stdio.print(' '); 
 } 
 stdio.moveCursor(0); 
 // 初始化信号量 
 for (int i = 0; i < 5; ++i) { 
 chop[i].initialize(1); 
 } 
 
 // 创建五个哲学家线程 
 programManager.executeThread(first_philosopher, nullptr, "first philosopher", 1); 
 programManager.executeThread(second_philosopher, nullptr, "second philosopher", 1); 
 programManager.executeThread(third_philosopher, nullptr, "third philosopher", 1); 
 programManager.executeThread(fourth_philosopher, nullptr, "fourth philosopher", 1); 
 programManager.executeThread(fifth_philosopher, nullptr, "fifth philosopher", 1); 
 
 asm_halt(); 
} 


extern "C" void setup_kernel()
{

    // 中断管理器
    interruptManager.initialize();
    interruptManager.enableTimeInterrupt();
    interruptManager.setTimeInterrupt((void *)asm_time_interrupt_handler);

    // 输出管理器
    stdio.initialize();

    // 进程/线程管理器
    programManager.initialize();

    // 创建第一个线程
    int pid = programManager.executeThread(first_thread, nullptr, "first thread", 1);
    if (pid == -1)
    {
        printf("can not execute thread\n");
        asm_halt();
    }

    ListItem *item = programManager.readyPrograms.front();
    PCB *firstThread = ListItem2PCB(item, tagInGeneralList);
    firstThread->status = RUNNING;
    programManager.readyPrograms.pop_front();
    programManager.running = firstThread;
    asm_switch_thread(0, firstThread);

    asm_halt();
}
