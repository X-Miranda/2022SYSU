#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <pthread.h>
#include <sys/time.h>

#define M 500
#define N 500

// ȫ�ֱ���
double u[M][N];
double w[M][N];
double mean;
double diff;

// �̲߳���
typedef struct {
    int start;
    int end;
    double (*u)[N];
    double (*w)[N];
} worker_arg;

// ��������
void* compute_temp(void *arg) {
    worker_arg *w_arg = (worker_arg*)arg;
    for (int i = w_arg->start; i < w_arg->end; i++) {
        for (int j = 1; j < N-1; j++) {
            w_arg->w[i][j] = (w_arg->u[i-1][j] + w_arg->u[i+1][j] +
                             w_arg->u[i][j-1] + w_arg->u[i][j+1]) * 0.25;
        }
    }
    return NULL;
}

// ��̬���Ȳ��м���
void parallel_for(int start, int end, void *(*func)(void*), void *arg, int num_threads) {
    pthread_t *threads = malloc(num_threads * sizeof(pthread_t));
    worker_arg *args = malloc(num_threads * sizeof(worker_arg));
    
    int chunk = (end - start) / num_threads;
    for (int i = 0; i < num_threads; i++) {
        args[i].start = start + i * chunk;
        args[i].end = (i == num_threads-1) ? end : start + (i+1)*chunk;
        args[i].u = ((worker_arg*)arg)->u;
        args[i].w = ((worker_arg*)arg)->w;
        
        pthread_create(&threads[i], NULL, func, &args[i]);
    }
    
    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }
    
    free(threads);
    free(args);
}

// ��ʼ���߽�
void init_boundaries() {
    for (int i = 1; i < M-1; i++) w[i][0] = 100.0;
    for (int i = 1; i < M-1; i++) w[i][N-1] = 100.0;
    for (int j = 0; j < N; j++) w[M-1][j] = 100.0;
    for (int j = 0; j < N; j++) w[0][j] = 0.0;
}

int main(int argc, char *argv[]) {
    int num_threads = (argc > 1) ? atoi(argv[1]) : 4;
    double epsilon = 0.001;
    int iterations = 0;
    
    // ��ʼ��
    init_boundaries();
    
    // ����ƽ��ֵ
    mean = 0.0;
    for (int i = 1; i < M-1; i++) mean += w[i][0] + w[i][N-1];
    for (int j = 0; j < N; j++) mean += w[M-1][j] + w[0][j];
    mean /= (2*M + 2*N - 4);
    
    // ��ʼ���ڲ��¶�
    worker_arg arg = {0, 0, u, w};
    for (int i = 1; i < M-1; i++) {
        for (int j = 1; j < N-1; j++) {
            w[i][j] = mean;
        }
    }
    
    printf("\nHEATED_PLATE_PTHREADS_STATIC\n");
    printf("  Spatial grid of %d by %d points.\n", M, N);
    printf("  Number of threads = %d\n", num_threads);
    printf("  Using static scheduling\n");
    printf("\nMEAN = %f\n", mean);
    
    struct timeval start, end;
    gettimeofday(&start, NULL);
    
    diff = epsilon;
    printf("\n Iteration  Change\n\n");
    
    while (diff >= epsilon) {
        // �����ֵ
        for (int i = 0; i < M; i++) {
            for (int j = 0; j < N; j++) {
                u[i][j] = w[i][j];
            }
        }
        
        // ���м���
        arg.start = 1;
        arg.end = M-1;
        parallel_for(1, M-1, compute_temp, &arg, num_threads);
        
        // �������
        diff = 0.0;
        for (int i = 1; i < M-1; i++) {
            for (int j = 1; j < N-1; j++) {
                double d = fabs(w[i][j] - u[i][j]);
                if (d > diff) diff = d;
            }
        }
        
        iterations++;
        if ((iterations & (iterations - 1)) == 0) { // ��ӡ2���ݴε���
            printf("  %8d  %f\n", iterations, diff);
        }
    }
    
    gettimeofday(&end, NULL);
    double wtime = (end.tv_sec - start.tv_sec) + 
                  (end.tv_usec - start.tv_usec) / 1000000.0;
    
    printf("\n  %8d  %f\n", iterations, diff);
    printf("\n  Error tolerance achieved.\n");
    printf("  Wallclock time = %.6f\n", wtime);
    printf("\nHEATED_PLATE_PTHREADS_STATIC:\n");
    printf("  Normal end of execution.\n");
    
    return 0;
}
