#include <pthread.h>
#include <stdlib.h>

typedef struct {
    int start;
    int end;
    int inc;
    void *(*functor)(int, void*);
    void *arg;
} thread_args;

typedef struct {
    int chunk_size;  // ���С�����ڶ�̬���ȣ�
    int schedule;    // 0-��̬, 1-��̬
} parallel_for_args;

static void* worker(void *args) {
    thread_args *t_args = (thread_args*)args;
    for (int i = t_args->start; i < t_args->end; i += t_args->inc) {
        t_args->functor(i, t_args->arg);
    }
    return NULL;
}

static void* dynamic_worker(void *args) {
    thread_args *t_args = (thread_args*)args;
    volatile int *next_iter_ptr = (volatile int*)t_args->arg; // �Ӳ����л�ȡ��������
    pthread_mutex_t *mutex_ptr = (pthread_mutex_t*)(t_args->arg + sizeof(int)); // ���� arg ���� mutex
    
    while (1) {
        pthread_mutex_lock(mutex_ptr);
        int current = *next_iter_ptr;
        if (current >= t_args->end) {
            pthread_mutex_unlock(mutex_ptr);
            break;
        }
        *next_iter_ptr += t_args->inc;
        pthread_mutex_unlock(mutex_ptr);
        
        for (int i = current; i < current + t_args->inc && i < t_args->end; i++) {
            t_args->functor(i, t_args->arg);
        }
    }
    return NULL;
}

// ��̬���Ȱ汾
void parallel_for_static(int start, int end, int inc, 
                       void *(*functor)(int, void*), 
                       void *arg, int num_threads) {
    pthread_t *threads = malloc(num_threads * sizeof(pthread_t));
    thread_args *t_args = malloc(num_threads * sizeof(thread_args));
    
    int range = end - start;
    int chunk = range / num_threads;
    
    for (int i = 0; i < num_threads; i++) {
        t_args[i].start = start + i * chunk;
        t_args[i].end = (i == num_threads - 1) ? end : start + (i + 1) * chunk;
        t_args[i].inc = inc;
        t_args[i].functor = functor;
        t_args[i].arg = arg;
        
        pthread_create(&threads[i], NULL, worker, &t_args[i]);
    }
    
    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }
    
    free(threads);
    free(t_args);
}

// ��̬���Ȱ汾
void parallel_for_dynamic(int start, int end, int inc, 
                        void *(*functor)(int, void*), 
                        void *arg, int num_threads, int chunk_size) {
    pthread_t *threads = malloc(num_threads * sizeof(pthread_t));
    thread_args *t_args = malloc(num_threads * sizeof(thread_args));
    
    // ����������next_iter �� mutex
    volatile int next_iter = start;
    pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
    
    // ����������������ṹ����
    typedef struct {
        volatile int *next_iter;
        pthread_mutex_t *mutex;
    } shared_data;
    shared_data sd = {&next_iter, &mutex};
    
    for (int i = 0; i < num_threads; i++) {
        t_args[i].start = start; // ��̬��������Ԥ�ȷ��䷶Χ
        t_args[i].end = end;
        t_args[i].inc = chunk_size; // ʹ�� chunk_size ��Ϊ����
        t_args[i].functor = functor;
        t_args[i].arg = (void*)&sd; // ���ݹ�������
        
        pthread_create(&threads[i], NULL, dynamic_worker, &t_args[i]);
    }
    
    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }
    
    free(threads);
    free(t_args);
    pthread_mutex_destroy(&mutex);
}
