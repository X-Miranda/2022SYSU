#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <complex.h>

#define PI 3.14159265358979323846

// �����ṹ��
typedef struct {
    double real;
    double imag;
} Complex;

// ��������
Complex create_complex(double real, double imag) {
    Complex c;
    c.real = real;
    c.imag = imag;
    return c;
}

// �����ӷ�
Complex complex_add(Complex a, Complex b) {
    return create_complex(a.real + b.real, a.imag + b.imag);
}

// ��������
Complex complex_sub(Complex a, Complex b) {
    return create_complex(a.real - b.real, a.imag - b.imag);
}

// �����˷�
Complex complex_mul(Complex a, Complex b) {
    return create_complex(a.real * b.real - a.imag * b.imag,
                         a.real * b.imag + a.imag * b.real);
}

// ���㸴����������ʽ
Complex complex_polar(double r, double theta) {
    return create_complex(r * cos(theta), r * sin(theta));
}

// ����FFTʵ��
void fft(Complex *x, int n) {
    if (n <= 1) return;

    // �����ڴ�
    Complex *even = (Complex *)malloc(n/2 * sizeof(Complex));
    Complex *odd = (Complex *)malloc(n/2 * sizeof(Complex));
    
    // �ָ���ż����
    for (int i = 0; i < n/2; ++i) {
        even[i] = x[2*i];
        odd[i] = x[2*i+1];
    }

    // �ݹ����
    fft(even, n/2);
    fft(odd, n/2);

    // �ϲ����
    for (int k = 0; k < n/2; ++k) {
        Complex t = complex_mul(complex_polar(1.0, -2 * PI * k / n), odd[k]);
        x[k] = complex_add(even[k], t);
        x[k+n/2] = complex_sub(even[k], t);
    }

    // �ͷ��ڴ�
    free(even);
    free(odd);
}

// MPI����FFT
void parallel_fft(Complex *local_data, int local_n, int rank, int size, int N, MPI_Datatype complex_type, MPI_Comm comm) {
    // ����FFT����
    fft(local_data, local_n);
    
    // ����ͨ�Ž׶�
    for (int step = 1; step < size; step *= 2) {
        if ((rank & step) == 0) {
            int partner = rank ^ step;
            
            // ���ͺͽ�������
            Complex *recv_data = (Complex *)malloc(local_n * sizeof(Complex));
            MPI_Sendrecv(local_data, local_n, complex_type, 
                        partner, 0, 
                        recv_data, local_n, complex_type, 
                        partner, 0, 
                        comm, MPI_STATUS_IGNORE);
            
            // �ϲ����
            for (int i = 0; i < local_n; ++i) {
                Complex t = complex_mul(
                    complex_polar(1.0, -2 * PI * (rank * local_n + i) / N), 
                    recv_data[i]);
                local_data[i] = complex_add(local_data[i], t);
            }
            free(recv_data);
        } else {
            int partner = rank ^ step;
            
            // ���ͺͽ�������
            Complex *recv_data = (Complex *)malloc(local_n * sizeof(Complex));
            MPI_Sendrecv(local_data, local_n, complex_type, 
                        partner, 0, 
                        recv_data, local_n, complex_type, 
                        partner, 0, 
                        comm, MPI_STATUS_IGNORE);
            
            // �ϲ����
            for (int i = 0; i < local_n; ++i) {
                Complex t = complex_mul(
                    complex_polar(1.0, -2 * PI * ((rank - step) * local_n + i) / N), 
                    local_data[i]);
                local_data[i] = complex_add(recv_data[i], t);
            }
            free(recv_data);
        }
    }
}

// �����Զ���MPI�����������ڸ���ͨ��
MPI_Datatype create_complex_type() {
    MPI_Datatype complex_type;
    int blocklengths[2] = {1, 1};
    MPI_Datatype types[2] = {MPI_DOUBLE, MPI_DOUBLE};
    MPI_Aint displacements[2];
    
    Complex dummy;
    MPI_Get_address(&dummy.real, &displacements[0]);
    MPI_Get_address(&dummy.imag, &displacements[1]);
    displacements[1] -= displacements[0];
    displacements[0] = 0;
    
    MPI_Type_create_struct(2, blocklengths, displacements, types, &complex_type);
    MPI_Type_commit(&complex_type);
    
    return complex_type;
}

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);
    
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    
    // �����ģN��Ĭ��Ϊ1024
    int N = (argc > 1) ? atoi(argv[1]) : 1024;
    
    // ȷ��N��2�������ܱ�����������
    if ((N & (N - 1)) != 0 || N % size != 0) {
        if (rank == 0) {
            fprintf(stderr, "N must be a power of 2 and divisible by the number of processes\n");
        }
        MPI_Finalize();
        return 1;
    }
    
    int local_n = N / size;
    Complex *local_data = (Complex *)malloc(local_n * sizeof(Complex));
    
    // �����Զ���MPI��������
    MPI_Datatype complex_type = create_complex_type();
    
    // ��ʼ������(�����̳�ʼ����ַ�)
    if (rank == 0) {
        Complex *global_data = (Complex *)malloc(N * sizeof(Complex));
        for (int i = 0; i < N; ++i) {
            global_data[i] = create_complex(i, 0); // �򵥲�������
        }
        
        // �ַ�����
        MPI_Scatter(global_data, local_n, complex_type,
                   local_data, local_n, complex_type,
                   0, MPI_COMM_WORLD);
        free(global_data);
    } else {
        MPI_Scatter(NULL, local_n, complex_type,
                   local_data, local_n, complex_type,
                   0, MPI_COMM_WORLD);
    }
    
    // ��ʱ��ʼ
    double start_time = MPI_Wtime();
    
    // ����FFT����
    parallel_fft(local_data, local_n, rank, size, N, complex_type, MPI_COMM_WORLD);
    
    // ��ʱ����
    double end_time = MPI_Wtime();
    
    // �ռ����(��ѡ)
    Complex *result = NULL;
    if (rank == 0) {
        result = (Complex *)malloc(N * sizeof(Complex));
    }
    
    MPI_Gather(local_data, local_n, complex_type,
              result, local_n, complex_type,
              0, MPI_COMM_WORLD);
    
    // ����������������
    if (rank == 0) {
        printf("FFT computation time: %.3f ms\n", (end_time - start_time) * 1000);
        
        // ����֤���(��ѡ)
        // for (int i = 0; i < 10; ++i) {
        //     printf("%f + %fi\n", result[i].real, result[i].imag);
        // }
        free(result);
    }
    
    // �ͷ���Դ
    free(local_data);
    MPI_Type_free(&complex_type);
    MPI_Finalize();
    return 0;
}
