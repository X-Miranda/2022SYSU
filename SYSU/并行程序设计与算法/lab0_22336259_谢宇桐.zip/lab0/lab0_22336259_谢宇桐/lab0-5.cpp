#include <iostream>
#include <vector>
#include <random>
#include <chrono>
#include <iomanip>

using namespace std;
using namespace std::chrono;

// �����������
vector<vector<double>> generate_matrix(int rows, int cols) {
    random_device rd;
    mt19937 gen(rd());
    uniform_real_distribution<double> dis(-1.0, 1.0);
    
    vector<vector<double>> matrix(rows, vector<double>(cols));
    for (auto& row : matrix) {
        for (auto& elem : row) {
            elem = dis(gen);
        }
    }
    return matrix;
}

// ѭ��չ���ľ���˷���չ������=4��
void unrolled_matrix_multiply(const vector<vector<double>>& A, 
                            const vector<vector<double>>& B,
                            vector<vector<double>>& C) {
    const int m = A.size();
    const int n = B[0].size();
    const int k = A[0].size();
    
    for (int i = 0; i < m; ++i) {
        for (int p = 0; p < k; ++p) {
            const double a_ip = A[i][p];
            int j = 0;
            
            // �ֶ�ѭ��չ����ÿ�δ���4��Ԫ�أ�
            for (; j < n - 3; j += 4) {
                C[i][j]     += a_ip * B[p][j];
                C[i][j+1]   += a_ip * B[p][j+1];
                C[i][j+2]   += a_ip * B[p][j+2];
                C[i][j+3]   += a_ip * B[p][j+3];
            }
            
            // ����ʣ��Ԫ��
            for (; j < n; ++j) {
                C[i][j] += a_ip * B[p][j];
            }
        }
    }
}

int main() {
    int m, n, k;
    cout << "����m n k: ";
    cin >> m >> n >> k;
    
    // �����������
    auto A = generate_matrix(m, k);
    auto B = generate_matrix(k, n);
    vector<vector<double>> C(m, vector<double>(n, 0));
    
    // Ԥ��
    unrolled_matrix_multiply(A, B, C);
    fill(C.begin(), C.end(), vector<double>(n, 0));
    
    // ��ʱ
    auto start = high_resolution_clock::now();
    unrolled_matrix_multiply(A, B, C);
    auto end = high_resolution_clock::now();
    
    double elapsed = duration_cast<duration<double>>(end - start).count();
    double gflops = (2.0 * m * n * k) / (elapsed * 1e9);

    // ������
    cout << fixed << setprecision(6);
    cout << "\n[�汾5��ѭ��չ���Ż�]\n";
    cout << "����ʱ��: " << elapsed << " ��\n";
    cout << "����: " << gflops << " GFLOPS\n";

    return 0;
}
