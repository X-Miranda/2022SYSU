#include <iostream>
#include <vector>
#include <ctime>
#include <iomanip>

using namespace std;

int main() {
    int m, n, k;
    
    // �������ά��
    cout << "����m n k: ";
    cin >> m >> n >> k;
    
    // �����������
    vector<vector<double>> A(m, vector<double>(k));
    vector<vector<double>> B(k, vector<double>(n));
    vector<vector<double>> C(m, vector<double>(n, 0));
    
    srand(time(0));
    for(int i=0; i<m; i++)
        for(int j=0; j<k; j++)
            A[i][j] = (double)rand()/RAND_MAX*2.0 - 1.0;
            
    for(int i=0; i<k; i++)
        for(int j=0; j<n; j++)
            B[i][j] = (double)rand()/RAND_MAX*2.0 - 1.0;

    // �������˷�����ʱ
    clock_t start = clock();
    
    for(int i=0; i<m; i++)
        for(int j=0; j<n; j++)
            for(int p=0; p<k; p++)
                C[i][j] += A[i][p] * B[p][j];
    
    double time_used = (double)(clock() - start)/CLOCKS_PER_SEC;
    double gflops = (2.0*m*n*k)/(time_used*1e9);

    // ������
    cout << fixed << setprecision(6);
    cout << "\n��ʱ: " << time_used << " ��" << endl;
    cout << "����: " << gflops << " GFLOPS" << endl;
    
    // ��ʾ���ֽ��
    cout << "\n����A���Ͻ� (6x6):" << endl;
    for(int i=0; i<min(6,m); i++) {
        for(int j=0; j<min(6,k); j++) 
            cout << setw(10) << A[i][j];
        cout << endl;
    }
    
    cout << "\n����B���Ͻ� (6x6):" << endl;
    for(int i=0; i<min(6,m); i++) {
        for(int j=0; j<min(6,k); j++) 
            cout << setw(10) << B[i][j];
        cout << endl;
    }
    
    cout << "\n����C���Ͻ� (6x6):" << endl;
    for(int i=0; i<min(6,m); i++) {
        for(int j=0; j<min(6,n); j++) 
            cout << setw(10) << C[i][j];
        cout << endl;
    }

    return 0;
}
