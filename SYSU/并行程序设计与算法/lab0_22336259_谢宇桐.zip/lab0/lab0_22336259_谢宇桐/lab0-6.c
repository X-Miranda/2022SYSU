#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "mkl.h"

#define min(x,y) (((x) < (y)) ? (x) : (y))

int main(int argc, char *argv[])
{
    // ��ȡ����ά�Ȳ���
    if (argc != 4) {
        printf("Usage: %s <m> <n> <k>\n", argv[0]);
        printf("Example: %s 512 512 512\n", argv[0]);
        return 1;
    }
    
    int m = atoi(argv[1]);
    int n = atoi(argv[2]);
    int k = atoi(argv[3]);

    double *A, *B, *C;
    int i, j;
    double alpha = 1.0, beta = 0.0;
    
    // �������������
    srand(time(NULL));

    // ��������ڴ�
    A = (double *)mkl_malloc(m*k*sizeof(double), 64);
    B = (double *)mkl_malloc(k*n*sizeof(double), 64);
    C = (double *)mkl_malloc(m*n*sizeof(double), 64);
    
    if (A == NULL || B == NULL || C == NULL) {
        printf("\n ERROR: Can't allocate memory for matrices. Aborting... \n\n");
        mkl_free(A);
        mkl_free(B);
        mkl_free(C);
        return 1;
    }

    // �����ʼ������
    printf("Initializing random matrices...\n");
    for (i = 0; i < m*k; i++) {
        A[i] = (double)rand() / RAND_MAX * 2.0 - 1.0;  // [-1, 1]��Χ�ڵ������
    }
    for (i = 0; i < k*n; i++) {
        B[i] = (double)rand() / RAND_MAX * 2.0 - 1.0;  // [-1, 1]��Χ�ڵ������
    }
    for (i = 0; i < m*n; i++) {
        C[i] = 0.0;
    }

    // ��ʱ��ʼ
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    
    // ����˷�����
    printf("Computing matrix product using Intel MKL dgemm...\n");
    cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, 
                m, n, k, alpha, A, k, B, n, beta, C, n);
    
    // ��ʱ����
    clock_gettime(CLOCK_MONOTONIC, &end);
    double time_used = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;
    
    // ����GFLOPS
    double gflops = (2.0 * m * n * k) / (time_used * 1e9);
    
    // ������
    printf("\nMatrix multiplication completed.\n");
    printf("Time: %.6f seconds\n", time_used);
    printf("Performance: %.2f GFLOPS\n", gflops);
    
    // ������־������ݣ����Ͻ�6x6��
    printf("\nTop-left corner of matrix A:\n");
    for (i = 0; i < min(m,6); i++) {
        for (j = 0; j < min(k,6); j++) {
            printf("%12.6f", A[j+i*k]);
        }
        printf("\n");
    }
    
    printf("\nTop-left corner of matrix B:\n");
    for (i = 0; i < min(k,6); i++) {
        for (j = 0; j < min(n,6); j++) {
            printf("%12.6f", B[j+i*n]);
        }
        printf("\n");
    }
    
    printf("\nTop-left corner of matrix C:\n");
    for (i = 0; i < min(m,6); i++) {
        for (j = 0; j < min(n,6); j++) {
            printf("%12.6f", C[j+i*n]);
        }
        printf("\n");
    }
    
    // �ͷ��ڴ�
    mkl_free(A);
    mkl_free(B);
    mkl_free(C);
    
    printf("\nDone.\n");
    return 0;
}
