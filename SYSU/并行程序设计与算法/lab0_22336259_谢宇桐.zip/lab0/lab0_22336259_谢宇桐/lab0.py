import numpy as np
import time
import sys


def matrix_multiply(m, n, k):
    # 生成随机矩阵 (范围[-1, 1])
    A = np.random.uniform(-1, 1, (m, k))
    B = np.random.uniform(-1, 1, (k, n))
    C = np.zeros((m, n))

    # 记录开始时间
    start = time.time()

    # 标准三重循环矩阵乘法
    for i in range(m):
        for j in range(n):
            for p in range(k):
                C[i][j] += A[i][p] * B[p][j]

    # 计算运行时间
    elapsed = time.time() - start

    # 计算GFLOPS
    gflops = (2 * m * n * k) / (elapsed * 1e9)

    return A, B, C, elapsed, gflops


if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python matrix_multiply.py <m> <n> <k>")
        print("Example: python matrix_multiply.py 512 512 512")
        sys.exit(1)

    try:
        m = int(sys.argv[1])
        n = int(sys.argv[2])
        k = int(sys.argv[3])

        if not all(512 <= x <= 2048 for x in [m, n, k]):
            raise ValueError("All dimensions must be in [512, 2048]")

    except ValueError as e:
        print(f"Error: {e}")
        sys.exit(1)

    print(f"Matrix multiplication: A({m}x{k}) * B({k}x{n})")

    A, B, C, time_used, gflops = matrix_multiply(m, n, k)

    print("\nResults:")
    print(f"Time: {time_used:.6f} seconds")
    print(f"Performance: {gflops:.6f} GFLOPS")


    # 打印部分矩阵内容（左上角6x6）
    def print_submatrix(matrix, name, rows=6, cols=6):
        print(f"\nTop-left corner of {name}:")
        for row in matrix[:rows]:
            print(" ".join(f"{x:12.6f}" for x in row[:cols]))


    print_submatrix(A, "matrix A")
    print_submatrix(B, "matrix B")
    print_submatrix(C, "matrix C")