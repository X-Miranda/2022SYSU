#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <math.h>
#include <time.h>
#include <stdatomic.h>

#define MAX_THREADS 16
#define TRIALS 5  // ÿ��ʵ���ظ�����

typedef struct {
    long points_per_thread;
    long hits;
    unsigned int seed;
} ThreadData;

_Atomic long total_hits = 0;  // ԭ�Ӽ�����

void* monte_carlo(void* arg) {
    ThreadData* data = (ThreadData*)arg;
    long local_hits = 0;
    
    for (long i = 0; i < data->points_per_thread; i++) {
        double x = (double)rand_r(&data->seed) / RAND_MAX * 2.0 - 1.0;
        double y = (double)rand_r(&data->seed) / RAND_MAX * 2.0 - 1.0;
        if (x*x + y*y <= 1.0) local_hits++;
    }
    
    atomic_fetch_add(&total_hits, local_hits);
    return NULL;
}

void run_experiment(long total_points, int num_threads) {
    total_hits = 0;
    pthread_t threads[MAX_THREADS];
    ThreadData thread_data[MAX_THREADS];
    long points_per_thread = total_points / num_threads;
    
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    
    for (int i = 0; i < num_threads; i++) {
        thread_data[i].points_per_thread = points_per_thread;
        thread_data[i].seed = time(NULL) ^ i;  // ��ͬ����
        pthread_create(&threads[i], NULL, monte_carlo, &thread_data[i]);
    }
    
    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }
    
    clock_gettime(CLOCK_MONOTONIC, &end);
    double time_used = (end.tv_sec - start.tv_sec) + 
                      (end.tv_nsec - start.tv_nsec) / 1e9;
    
    double pi_estimate = 4.0 * total_hits / total_points;
    double error = fabs(pi_estimate - M_PI) / M_PI * 100;
    
    printf("Points=%-10ld | Threads=%-2d | ��=%.6f | Error=%.2f%% | Time=%.4fs\n",
           total_points, num_threads, pi_estimate, error, time_used);
}

int main() {
    long point_counts[] = {1000, 10000, 100000, 1000000, 10000000};
    int thread_counts[] = {1, 2, 4, 8, 16};
    
    printf("=========== Monte Carlo �� Estimation ===========\n");
    for (long n = 0; n < sizeof(point_counts)/sizeof(long); n++) {
        for (int t = 0; t < sizeof(thread_counts)/sizeof(int); t++) {
            for (int trial = 0; trial < TRIALS; trial++) {
                run_experiment(point_counts[n], thread_counts[t]);
            }
        }
    }
    return 0;
}
