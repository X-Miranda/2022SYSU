#include <stdio.h>
#include <pthread.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>

#define NUM_EQUATIONS 1000000  // 100�򷽳�
#define MAX_THREADS 32         // ���֧��32�߳�

typedef struct {
    double a, b, c;
    double x1, x2;
} __attribute__((aligned(64))) Equation;  // ǿ��64�ֽڶ���

typedef struct {
    Equation* equations;
    size_t start;
    size_t end;
} ThreadData;

void solve_equation(Equation* eq) {
    // �����������㸺��
    for (volatile int i = 0; i < 100; i++) {}  // ģ������ӳ�
    
    double delta = eq->b * eq->b - 4 * eq->a * eq->c;
    double denom = 2 * eq->a;
    eq->x1 = (-eq->b + sqrt(delta)) / denom;
    eq->x2 = (-eq->b - sqrt(delta)) / denom;
}

void* worker_thread(void* arg) {
    ThreadData* data = (ThreadData*)arg;
    for (size_t i = data->start; i < data->end; i++) {
        solve_equation(&data->equations[i]);
    }
    return NULL;
}

double run_test(int num_threads) {
    // �����ڴ棨ʹ��posix_memalign��֤���룩
    Equation* equations;
    posix_memalign((void**)&equations, 64, NUM_EQUATIONS * sizeof(Equation));
    
    // ��ʼ������
    for (size_t i = 0; i < NUM_EQUATIONS; i++) {
        equations[i].a = (rand() % 200) - 100 + 0.5;
        equations[i].b = (rand() % 200) - 100 + 0.5;
        equations[i].c = (rand() % 200) - 100 + 0.5;
    }

    pthread_t threads[MAX_THREADS];
    ThreadData thread_data[MAX_THREADS];
    const size_t chunk_size = NUM_EQUATIONS / num_threads;
    
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    
    // �����߳�
    for (int i = 0; i < num_threads; i++) {
        thread_data[i].equations = equations;
        thread_data[i].start = i * chunk_size;
        thread_data[i].end = (i == num_threads - 1) ? NUM_EQUATIONS : (i + 1) * chunk_size;
        pthread_create(&threads[i], NULL, worker_thread, &thread_data[i]);
    }
    
    // �ȴ��߳����
    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }
    
    clock_gettime(CLOCK_MONOTONIC, &end);
    double time_used = (end.tv_sec - start.tv_sec) + 
                      (end.tv_nsec - start.tv_nsec) / 1e9;
    
    free(equations);
    return time_used;
}

int main() {
    // ��ȡCPU������
    const int phys_cores = sysconf(_SC_NPROCESSORS_ONLN);
    printf("Physical cores: %d\n", phys_cores);
    
    // Ԥ��CPU����
    run_test(1);
    
    // ��ʽ����
    for (int t = 1; t <= 16; t++) {
        double total_time = 0;
        for (int repeat = 0; repeat < 3; repeat++) {  // ��β���ȡƽ��
            total_time += run_test(t);
        }
        printf("Threads=%2d | Avg Time=%.6f sec | Speedup=%.2fx\n",
               t, total_time/3, run_test(1)/(total_time/3));
    }
    
    return 0;
}
