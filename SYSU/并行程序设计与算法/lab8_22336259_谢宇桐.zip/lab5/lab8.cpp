#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <queue>
#include <limits>
#include <chrono>
#include <omp.h>
#include <sstream>

using namespace std;

const float INF = numeric_limits<float>::infinity();

class Graph {
private:
    unordered_map<int, unordered_map<int, float>> adj_list;
    vector<int> nodes;

public:
    void addEdge(int src, int dest, float distance) {
        adj_list[src][dest] = distance;
        adj_list[dest][src] = distance; // ����ͼ��˫������
    }

    void buildNodesList() {
        for (const auto& pair : adj_list) {
            nodes.push_back(pair.first);
        }
    }

    vector<int> getNodes() const {
        return nodes;
    }

    vector<float> dijkstra(int start) const {
        unordered_map<int, float> distances;
        for (const auto& node : nodes) {
            distances[node] = INF;
        }
        distances[start] = 0;

        priority_queue<pair<float, int>, vector<pair<float, int>>, greater<pair<float, int>>> pq;
        pq.push({0, start});

        while (!pq.empty()) {
            auto current = pq.top();
            pq.pop();
            int u = current.second;
            float dist_u = current.first;

            if (dist_u > distances[u]) continue;

            if (adj_list.find(u) == adj_list.end()) continue;

            for (const auto& neighbor : adj_list.at(u)) {
                int v = neighbor.first;
                float weight = neighbor.second;
                if (distances[v] > distances[u] + weight) {
                    distances[v] = distances[u] + weight;
                    pq.push({distances[v], v});
                }
            }
        }

        vector<float> result;
        for (const auto& node : nodes) {
            result.push_back(distances[node]);
        }
        return result;
    }
};

vector<pair<int, int>> readTestCases(const string& filename) {
    vector<pair<int, int>> test_cases;
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "�޷��򿪲����ļ�: " << filename << endl;
        exit(1);
    }

    string line;
    while (getline(file, line)) {
        if (line.empty()) continue;
        size_t pos = line.find(',');
        if (pos == string::npos) pos = line.find(' '); // Ҳ֧�ֿո�ָ�
        if (pos == string::npos) continue;
        
        try {
            int src = stoi(line.substr(0, pos));
            int dest = stoi(line.substr(pos + 1));
            test_cases.emplace_back(src, dest);
        } catch (...) {
            cerr << "������ʧ��: " << line << endl;
        }
    }
    file.close();
    return test_cases;
}

Graph readGraph(const string& filename) {
    Graph graph;
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "�޷���ͼ�ļ�: " << filename << endl;
        exit(1);
    }

    string line;
    while (getline(file, line)) {
        if (line.empty()) continue;
        
        // ����CSV��ʽ
        vector<string> parts;
        size_t start = 0, end;
        while ((end = line.find(',', start)) != string::npos) {
            parts.push_back(line.substr(start, end - start));
            start = end + 1;
        }
        parts.push_back(line.substr(start));
        
        if (parts.size() < 3) {
            cerr << "��ʽ����������: " << line << endl;
            continue;
        }

        try {
            int src = stoi(parts[0]);
            int dest = stoi(parts[1]);
            float distance = stof(parts[2]);
            graph.addEdge(src, dest, distance);
        } catch (...) {
            cerr << "������ʧ��: " << line << endl;
        }
    }
    file.close();
    graph.buildNodesList();
    return graph;
}

int main(int argc, char* argv[]) {

    string graph_file = "updated_mouse.csv";
    string test_file = "test_mouse.txt";
    int max_threads = 16;

    cout << "��ȡͼ����..." << endl;
    Graph graph = readGraph(graph_file);
    vector<int> nodes = graph.getNodes();
    
    cout << "��ȡ��������..." << endl;
    vector<pair<int, int>> test_cases = readTestCases(test_file);

    // Ϊÿ���߳������в���
    for (int num_threads = 1; num_threads <= max_threads;) {
        omp_set_num_threads(num_threads);
        
        auto start_time = chrono::high_resolution_clock::now();
        
        vector<vector<float>> all_distances(nodes.size());
        
        #pragma omp parallel for
        for (size_t i = 0; i < nodes.size(); i++) {
            all_distances[i] = graph.dijkstra(nodes[i]);
        }
        
        auto end_time = chrono::high_resolution_clock::now();
        auto duration = chrono::duration_cast<chrono::milliseconds>(end_time - start_time).count();
        
        // ������������
        unordered_map<int, size_t> node_index;
        for (size_t i = 0; i < nodes.size(); i++) {
            node_index[nodes[i]] = i;
        }
        
        vector<float> test_results;
        for (const auto& test_case : test_cases) {
            int src = test_case.first;
            int dest = test_case.second;
            if (node_index.find(src) == node_index.end() || node_index.find(dest) == node_index.end()) {
                test_results.push_back(INF);
            } else {
                size_t src_idx = node_index[src];
                size_t dest_idx = node_index[dest];
                test_results.push_back(all_distances[src_idx][dest_idx]);
            }
        }
        
        cout << "�߳���: " << num_threads << endl;
        cout << "��ʱ��(ms): " << duration << endl;
        cout << "���Խ��: ";
        for (float dist : test_results) {
            if (dist == INF) {
                cout << "INF ";
            } else {
                cout << dist << " ";
            }
        }
        cout << endl << endl;
        num_threads *= 2;
    }

    return 0;
}
