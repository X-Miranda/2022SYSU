#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <mpi.h>

#define MIN_SIZE 128
#define MAX_SIZE 2048

// ����ṹ�嶨��
typedef struct {
    double *data;
    int rows;
    int cols;
} Matrix;

// �����������
void generate_matrix(Matrix *mat) {
    for (int i = 0; i < mat->rows * mat->cols; i++) {
        mat->data[i] = (double)rand() / RAND_MAX * 10.0;
    }
}

// ��ӡ����ǰ5x5����
void print_matrix(Matrix *mat) {
    int print_rows = mat->rows > 5 ? 5 : mat->rows;
    int print_cols = mat->cols > 5 ? 5 : mat->cols;
    
    for (int i = 0; i < print_rows; i++) {
        for (int j = 0; j < print_cols; j++) {
            printf("%8.2f ", mat->data[i * mat->cols + j]);
        }
        printf("\n");
    }
}


// ================== ʵ��1: ����ͨ�� ==================
void parallel_matrix_multiply_collective(int rank, int size, Matrix *A, Matrix *B, Matrix *C) {
    int rows_per_process = A->rows / size;
    int remaining_rows = A->rows % size;
    
    Matrix local_A = {NULL, rows_per_process, A->cols};
    Matrix local_C = {NULL, rows_per_process, B->cols};
    
    if (rank == 0) {
        local_A.rows += remaining_rows;
    }
    
    local_A.data = (double *)malloc(local_A.rows * local_A.cols * sizeof(double));
    local_C.data = (double *)malloc(local_A.rows * local_C.cols * sizeof(double));
    
    // ׼��Scatterv����
    int *sendcounts = (int *)malloc(size * sizeof(int));
    int *displs = (int *)malloc(size * sizeof(int));
    
    for (int i = 0; i < size; i++) {
        sendcounts[i] = rows_per_process * A->cols;
        displs[i] = i * rows_per_process * A->cols;
    }
    sendcounts[0] += remaining_rows * A->cols;
    
    // �ַ�����
    MPI_Scatterv(A->data, sendcounts, displs, MPI_DOUBLE,
                local_A.data, local_A.rows * local_A.cols, MPI_DOUBLE,
                0, MPI_COMM_WORLD);
    
    // �㲥����B
    if (rank != 0) {
        B->data = (double *)malloc(B->rows * B->cols * sizeof(double));
    }
    MPI_Bcast(B->data, B->rows * B->cols, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    
    // �ֲ�����˷�
    for (int i = 0; i < local_A.rows; i++) {
        for (int j = 0; j < B->cols; j++) {
            double sum = 0.0;
            for (int l = 0; l < A->cols; l++) {
                sum += local_A.data[i * A->cols + l] * B->data[l * B->cols + j];
            }
            local_C.data[i * B->cols + j] = sum;
        }
    }
    
    // �ռ����
    MPI_Gatherv(local_C.data, rows_per_process * B->cols, MPI_DOUBLE,
               C->data, sendcounts, displs, MPI_DOUBLE,
               0, MPI_COMM_WORLD);
    
    free(sendcounts);
    free(displs);
    free(local_A.data);
    free(local_C.data);
}

// ================== ʵ��2: ʹ��MPI_Type_create_struct ==================
typedef struct {
    double *data;
    int rows;
    int cols;
    int size;
} MatrixData;

void create_matrix_data_type(MPI_Datatype *matrix_data_type) {
    MatrixData dummy;
    MPI_Aint displacements[4];
    MPI_Datatype types[4] = {MPI_DOUBLE, MPI_INT, MPI_INT, MPI_INT};
    int blocklengths[4] = {1, 1, 1, 1};
    
    MPI_Get_address(&dummy.data, &displacements[0]);
    MPI_Get_address(&dummy.rows, &displacements[1]);
    MPI_Get_address(&dummy.cols, &displacements[2]);
    MPI_Get_address(&dummy.size, &displacements[3]);
    
    MPI_Aint base_address;
    MPI_Get_address(&dummy, &base_address);
    for (int i = 0; i < 4; i++) {
        displacements[i] = MPI_Aint_diff(displacements[i], base_address);
    }
    
    MPI_Type_create_struct(4, blocklengths, displacements, types, matrix_data_type);
    MPI_Type_commit(matrix_data_type);
}

void parallel_matrix_multiply_struct(int rank, int size, Matrix *A, Matrix *B, Matrix *C) {
    int rows_per_process = A->rows / size;
    int remaining_rows = A->rows % size;
    
    Matrix local_A = {NULL, rows_per_process, A->cols};
    Matrix local_C = {NULL, rows_per_process, B->cols};
    
    if (rank == 0) {
        local_A.rows += remaining_rows;
    }
    
    local_A.data = (double *)malloc(local_A.rows * local_A.cols * sizeof(double));
    local_C.data = (double *)malloc(local_A.rows * local_C.cols * sizeof(double));
    
    // �ַ����� - ʹ�ñ�׼ͨ�ŷ�ʽ
    if (rank == 0) {
        // �������ݸ���������
        int offset = (rows_per_process + remaining_rows) * A->cols;
        for (int i = 1; i < size; i++) {
            MPI_Send(A->data + offset, rows_per_process * A->cols, MPI_DOUBLE, i, 0, MPI_COMM_WORLD);
            offset += rows_per_process * A->cols;
        }
        // �����̱����Լ�������
        memcpy(local_A.data, A->data, (rows_per_process + remaining_rows) * A->cols * sizeof(double));
    } else {
        MPI_Recv(local_A.data, rows_per_process * A->cols, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    }
    
    // �㲥����B
    if (rank != 0) {
        B->data = (double *)malloc(B->rows * B->cols * sizeof(double));
    }
    MPI_Bcast(B->data, B->rows * B->cols, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    
    // �ֲ�����˷�
    for (int i = 0; i < local_A.rows; i++) {
        for (int j = 0; j < B->cols; j++) {
            double sum = 0.0;
            for (int l = 0; l < A->cols; l++) {
                sum += local_A.data[i * A->cols + l] * B->data[l * B->cols + j];
            }
            local_C.data[i * B->cols + j] = sum;
        }
    }
    
    // �ռ����
    if (rank == 0) {
        memcpy(C->data, local_C.data, (rows_per_process + remaining_rows) * B->cols * sizeof(double));
        int offset = (rows_per_process + remaining_rows) * B->cols;
        for (int i = 1; i < size; i++) {
            MPI_Recv(C->data + offset, rows_per_process * B->cols, MPI_DOUBLE, i, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            offset += rows_per_process * B->cols;
        }
    } else {
        MPI_Send(local_C.data, rows_per_process * B->cols, MPI_DOUBLE, 0, 1, MPI_COMM_WORLD);
    }
    
    free(local_A.data);
    free(local_C.data);
}

// ================== ʵ��3: ���л��� ==================
void parallel_matrix_multiply_col_split(int rank, int size, Matrix *A, Matrix *B, Matrix *C) {
    int cols_per_process = B->cols / size;
    int remaining_cols = B->cols % size;
    
    Matrix local_B = {NULL, B->rows, cols_per_process};
    Matrix local_C = {NULL, A->rows, cols_per_process};
    
    if (rank == 0) {
        local_B.cols += remaining_cols;
        local_C.cols += remaining_cols;
    }
    
    local_B.data = (double *)malloc(local_B.rows * local_B.cols * sizeof(double));
    local_C.data = (double *)malloc(local_C.rows * local_C.cols * sizeof(double));
    
    // �ַ�B�������
    if (rank == 0) {
        // �����̱���������
        for (int i = 0; i < B->rows; i++) {
            memcpy(local_B.data + i * local_B.cols, 
                  B->data + i * B->cols, 
                  local_B.cols * sizeof(double));
        }
        
        // ���������и���������
        for (int p = 1; p < size; p++) {
            int start_col = p * cols_per_process + remaining_cols;
            for (int i = 0; i < B->rows; i++) {
                MPI_Send(B->data + i * B->cols + start_col, 
                        cols_per_process, MPI_DOUBLE, p, 0, MPI_COMM_WORLD);
            }
        }
    } else {
        // ����������
        for (int i = 0; i < B->rows; i++) {
            MPI_Recv(local_B.data + i * local_B.cols, 
                    local_B.cols, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }
    }
    
    // �㲥����A
    if (rank != 0) {
        A->data = (double *)malloc(A->rows * A->cols * sizeof(double));
    }
    MPI_Bcast(A->data, A->rows * A->cols, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    
    // �ֲ�����˷�
    for (int i = 0; i < A->rows; i++) {
        for (int j = 0; j < local_B.cols; j++) {
            double sum = 0.0;
            for (int l = 0; l < A->cols; l++) {
                sum += A->data[i * A->cols + l] * local_B.data[l * local_B.cols + j];
            }
            local_C.data[i * local_C.cols + j] = sum;
        }
    }
    
    // �ռ����
    if (rank == 0) {
        // ���������̵Ľ��
        for (int i = 0; i < A->rows; i++) {
            memcpy(C->data + i * B->cols, 
                  local_C.data + i * local_C.cols, 
                  local_C.cols * sizeof(double));
        }
        
        // �����������̵Ľ��
        for (int p = 1; p < size; p++) {
            int start_col = p * cols_per_process + remaining_cols;
            for (int i = 0; i < A->rows; i++) {
                MPI_Recv(C->data + i * B->cols + start_col, 
                        cols_per_process, MPI_DOUBLE, p, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            }
        }
    } else {
        // ���ͽ����������
        for (int i = 0; i < A->rows; i++) {
            MPI_Send(local_C.data + i * local_C.cols, 
                    local_C.cols, MPI_DOUBLE, 0, 1, MPI_COMM_WORLD);
        }
    }
    
    free(local_B.data);
    free(local_C.data);
}

// ================== ���ܲ��Ժ��� ==================
void performance_test(int rank, int size, void (*multiply_func)(int, int, Matrix*, Matrix*, Matrix*)) {
    int sizes[] = {128, 256, 512, 1024, 2048};
    double times[5] = {0};
    
    if (rank == 0) {
        printf("Performance Test Running...\n");
        printf("+----------+-----------+-----------+-----------+-----------+-----------+\n");
        printf("| ������   | 128x128   | 256x256   | 512x512   | 1024x1024 | 2048x2048 |\n");
        printf("+----------+-----------+-----------+-----------+-----------+-----------+\n");
    }
    
    for (int s = 0; s < 5; s++) {
        int n = sizes[s];
        Matrix A = {NULL, n, n};
        Matrix B = {NULL, n, n};
        Matrix C = {NULL, n, n};
        
        if (rank == 0) {
            A.data = (double *)malloc(n * n * sizeof(double));
            B.data = (double *)malloc(n * n * sizeof(double));
            C.data = (double *)malloc(n * n * sizeof(double));
            
            srand(time(NULL));
            generate_matrix(&A);
            generate_matrix(&B);
        } else {
            B.data = (double *)malloc(n * n * sizeof(double));
        }
        
        MPI_Barrier(MPI_COMM_WORLD);
        double start_time = MPI_Wtime();
        
        multiply_func(rank, size, &A, &B, &C);
        
        MPI_Barrier(MPI_COMM_WORLD);
        double end_time = MPI_Wtime();
        
        if (rank == 0) {
            times[s] = end_time - start_time;
            free(A.data);
            free(B.data);
            free(C.data);
        }
    }
    
    if (rank == 0) {
        printf("| %-8d | %9.6f | %9.6f | %9.6f | %9.6f | %9.6f |\n",
               size, times[0], times[1], times[2], times[3], times[4]);
        printf("+----------+-----------+-----------+-----------+-----------+-----------+\n");
    }
}

int main(int argc, char *argv[]) {
    int rank, size;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    
    if (argc == 1) {
        // ��������ʵ�ַ�ʽ
        
        if (rank == 0) printf("\n=== ����ͨ�� ===\n");
        performance_test(rank, size, parallel_matrix_multiply_collective);
        
        if (rank == 0) printf("\n=== �ṹ��ͨ�� ===\n");
        performance_test(rank, size, parallel_matrix_multiply_struct);
        
        if (rank == 0) printf("\n=== ���л��� ===\n");
        performance_test(rank, size, parallel_matrix_multiply_col_split);
    } else if (argc == 4) {
        // ����ָ������˷�
        int m = atoi(argv[1]);
        int n = atoi(argv[2]);
        int k = atoi(argv[3]);
        
        Matrix A = {NULL, m, n};
        Matrix B = {NULL, n, k};
        Matrix C = {NULL, m, k};
        double start_time, end_time;
        
        if (rank == 0) {
            A.data = (double *)malloc(m * n * sizeof(double));
            B.data = (double *)malloc(n * k * sizeof(double));
            C.data = (double *)malloc(m * k * sizeof(double));
            
            srand(time(NULL));
            generate_matrix(&A);
            generate_matrix(&B);
            
            printf("Matrix Multiplication: %dx%d * %dx%d\n", m, n, n, k);
            printf("Using %d MPI processes with collective communication\n", size);
            
            start_time = MPI_Wtime();
        }
        
        parallel_matrix_multiply_collective(rank, size, &A, &B, &C);
        
        if (rank == 0) {
            end_time = MPI_Wtime();
            
            printf("\nMatrix A (first 5x5):\n");
            print_matrix(&A);
            printf("\nMatrix B (first 5x5):\n");
            print_matrix(&B);
            printf("\nResult Matrix C (first 5x5):\n");
            print_matrix(&C);
            
            printf("\nTime taken: %.6f seconds\n", end_time - start_time);
            
            free(A.data);
            free(B.data);
            free(C.data);
        }
    } else {
        if (rank == 0) {
            printf("Usage:\n");
            printf("  For performance test: mpirun -n <processes> %s\n", argv[0]);
            printf("  For specific matrix: mpirun -n <processes> %s <m> <n> <k>\n", argv[0]);
        }
    }
    
    MPI_Finalize();
    return 0;
}
