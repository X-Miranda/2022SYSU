#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>

// �����������
void generate_random_matrix(double *matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            matrix[i * cols + j] = (double)rand() / RAND_MAX * 10.0;
        }
    }
}

// ��ӡ���󣨽�����С������ԣ�
void print_matrix(double *matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%.2f ", matrix[i * cols + j]);
        }
        printf("\n");
    }
}

// OpenMP����˷���Ĭ�ϵ��ȣ�
void matrix_multiply(double *A, double *B, double *C, int m, int n, int k) {
    #pragma omp parallel for
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < k; j++) {
            double sum = 0.0;
            for (int l = 0; l < n; l++) {
                sum += A[i * n + l] * B[l * k + j];
            }
            C[i * k + j] = sum;
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc != 5) {
        printf("Usage: %s <m> <n> <k> <threads>\n", argv[0]);
        return 1;
    }

    int m = atoi(argv[1]);
    int n = atoi(argv[2]);
    int k = atoi(argv[3]);
    int num_threads = atoi(argv[4]);

    // �����߳���
    omp_set_num_threads(num_threads);

    // �����ڴ�
    double *A = (double *)malloc(m * n * sizeof(double));
    double *B = (double *)malloc(n * k * sizeof(double));
    double *C = (double *)malloc(m * k * sizeof(double));

    // �����������
    srand(time(NULL));
    generate_random_matrix(A, m, n);
    generate_random_matrix(B, n, k);

    // ��ʱ��ʼ
    double start_time = omp_get_wtime();

    // ����˷�
    matrix_multiply(A, B, C, m, n, k);

    // ��ʱ����
    double end_time = omp_get_wtime();
    double elapsed_time = end_time - start_time;

    // �����������ڴ����ע�͵���ӡ���֣�
    if (m <= 8 && n <= 8 && k <= 8) {
        printf("Matrix A:\n");
        print_matrix(A, m, n);
        printf("\nMatrix B:\n");
        print_matrix(B, n, k);
        printf("\nMatrix C (A x B):\n");
        print_matrix(C, m, k);
    }

    printf("\nMatrix multiplication time: %.6f seconds\n", elapsed_time);

    // �ͷ��ڴ�
    free(A);
    free(B);
    free(C);

    return 0;
}
