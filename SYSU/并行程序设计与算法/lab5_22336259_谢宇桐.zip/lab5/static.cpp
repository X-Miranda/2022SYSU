#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>

// �����������
void generate_random_matrix(double *matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            matrix[i * cols + j] = (double)rand() / RAND_MAX * 10.0;
        }
    }
}

// OpenMP����˷�����̬���ȣ�
void matrix_multiply_static(double *A, double *B, double *C, int m, int n, int k, int chunk_size) {
    #pragma omp parallel for schedule(static, chunk_size)
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < k; j++) {
            double sum = 0.0;
            for (int l = 0; l < n; l++) {
                sum += A[i * n + l] * B[l * k + j];
            }
            C[i * k + j] = sum;
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc != 6) {
        printf("Usage: %s <m> <n> <k> <threads> <chunk_size>\n", argv[0]);
        printf("Example: %s 1024 1024 1024 4 64\n");
        return 1;
    }

    int m = atoi(argv[1]);
    int n = atoi(argv[2]);
    int k = atoi(argv[3]);
    int num_threads = atoi(argv[4]);
    int chunk_size = atoi(argv[5]);

    // �����߳���
    omp_set_num_threads(num_threads);
    omp_set_dynamic(0); // ���ö�̬�����߳���

    // �����ڴ�
    double *A = (double *)malloc(m * n * sizeof(double));
    double *B = (double *)malloc(n * k * sizeof(double));
    double *C = (double *)malloc(m * k * sizeof(double));

    // �����������
    srand(time(NULL));
    generate_random_matrix(A, m, n);
    generate_random_matrix(B, n, k);

    // ��ʼ���������
    #pragma omp parallel for
    for (int i = 0; i < m * k; i++) {
        C[i] = 0.0;
    }

    // ��ʱ��ʼ
    double start_time = omp_get_wtime();

    // ����˷�����̬���ȣ�
    matrix_multiply_static(A, B, C, m, n, k, chunk_size);

    // ��ʱ����
    double end_time = omp_get_wtime();
    double elapsed_time = end_time - start_time;

    printf("Matrix %dx%d * %dx%d with %d threads (static, chunk=%d): %.6f seconds\n",
           m, n, n, k, num_threads, chunk_size, elapsed_time);

    // �ͷ��ڴ�
    free(A);
    free(B);
    free(C);

    return 0;
}
