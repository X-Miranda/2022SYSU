#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>

typedef struct {
    double *A, *B, *C;
    int m, n, k;
    int start_row, end_row;
} ThreadData;

void *matmul_thread(void *arg) {
    ThreadData *data = (ThreadData *)arg;
    for (int i = data->start_row; i < data->end_row; i++) {
        for (int j = 0; j < data->k; j++) {
            double sum = 0.0;
            for (int l = 0; l < data->n; l++) {
                sum += data->A[i * data->n + l] * data->B[l * data->k + j];
            }
            data->C[i * data->k + j] = sum;
        }
    }
    return NULL;
}

void matrix_multiply_pthreads(double *A, double *B, double *C, int m, int n, int k, int num_threads) {
    pthread_t threads[num_threads];
    ThreadData thread_data[num_threads];
    int rows_per_thread = m / num_threads;
    
    for (int i = 0; i < num_threads; i++) {
        thread_data[i].A = A;
        thread_data[i].B = B;
        thread_data[i].C = C;
        thread_data[i].m = m;
        thread_data[i].n = n;
        thread_data[i].k = k;
        thread_data[i].start_row = i * rows_per_thread;
        thread_data[i].end_row = (i == num_threads - 1) ? m : (i + 1) * rows_per_thread;
        
        pthread_create(&threads[i], NULL, matmul_thread, &thread_data[i]);
    }
    
    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }
}

// ���������������֮ǰ��ͬ
void generate_random_matrix(double *matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            matrix[i * cols + j] = (double)rand() / RAND_MAX * 10.0;
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc != 5) {
        printf("Usage: %s <m> <n> <k> <threads>\n", argv[0]);
        return 1;
    }

    int m = atoi(argv[1]);
    int n = atoi(argv[2]);
    int k = atoi(argv[3]);
    int num_threads = atoi(argv[4]);

    double *A = (double *)malloc(m * n * sizeof(double));
    double *B = (double *)malloc(n * k * sizeof(double));
    double *C = (double *)malloc(m * k * sizeof(double));

    srand(time(NULL));
    generate_random_matrix(A, m, n);
    generate_random_matrix(B, n, k);

    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);

    matrix_multiply_pthreads(A, B, C, m, n, k, num_threads);

    clock_gettime(CLOCK_MONOTONIC, &end);
    double elapsed_time = (end.tv_sec - start.tv_sec) + 
                         (end.tv_nsec - start.tv_nsec) / 1e9;

    printf("Pthreads: Matrix %dx%d * %dx%d with %d threads: %.6f seconds\n",
           m, n, n, k, num_threads, elapsed_time);

    free(A);
    free(B);
    free(C);
    return 0;
}
