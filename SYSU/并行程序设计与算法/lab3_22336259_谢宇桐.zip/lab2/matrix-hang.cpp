#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <sched.h>
#include <unistd.h>
#include <math.h>

#define MAX_THREADS 16

typedef struct {
    int m, n, k;
    double **A, **B, **C;
    int thread_id;
    int num_threads;
} ThreadData;

void *matrix_multiply_thread(void *arg) {
    ThreadData *data = (ThreadData *)arg;
    
    // �����߳��׺���
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(data->thread_id % sysconf(_SC_NPROCESSORS_ONLN), &cpuset);
    pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpuset);

    // �򵥵��л��֣��Ƿֿ�汾��
    int chunk_size = data->m / data->num_threads;
    int start_row = data->thread_id * chunk_size;
    int end_row = (data->thread_id == data->num_threads - 1) ? data->m : start_row + chunk_size;

    for (int i = start_row; i < end_row; i++) {
        for (int j = 0; j < data->k; j++) {
            double sum = 0;
            // ѭ��չ���Ż���������
            int l;
            for (l = 0; l < data->n - 4; l += 4) {
                sum += data->A[i][l] * data->B[l][j];
                sum += data->A[i][l+1] * data->B[l+1][j];
                sum += data->A[i][l+2] * data->B[l+2][j];
                sum += data->A[i][l+3] * data->B[l+3][j];
            }
            // ����ʣ��Ԫ��
            for (; l < data->n; l++) {
                sum += data->A[i][l] * data->B[l][j];
            }
            data->C[i][j] = sum;
        }
    }
    return NULL;
}

double **allocate_matrix(int rows, int cols) {
    double **matrix = (double **)malloc(rows * sizeof(double *));
    for (int i = 0; i < rows; i++) {
        posix_memalign((void **)&matrix[i], 64, cols * sizeof(double));  // �����ڴ����
    }
    return matrix;
}

void free_matrix(double **matrix, int rows) {
    for (int i = 0; i < rows; i++) {
        free(matrix[i]);
    }
    free(matrix);
}

void random_fill_matrix(double **matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            matrix[i][j] = (double)rand() / RAND_MAX * 100.0;
        }
    }
}

void print_matrix(double **matrix, int rows, int cols, const char *name) {
    printf("Matrix %s (first 5x5):\n", name);
    for (int i = 0; i < fmin(5, rows); i++) {
        for (int j = 0; j < fmin(5, cols); j++) {
            printf("%8.2f ", matrix[i][j]);
        }
        printf("\n");
    }
}

int main(int argc, char *argv[]) {

    int m = atoi(argv[1]);
    int n = atoi(argv[2]);
    int k = atoi(argv[3]);
    int num_threads = atoi(argv[4]);


    // ��������飨������
    int num_cores = sysconf(_SC_NPROCESSORS_ONLN);
    if (num_threads > num_cores * 2) {
        printf("Warning: Thread count (%d) exceeds 2x physical cores (%d)\n", 
               num_threads, num_cores);
    }

    srand(time(NULL));

    // �����ڴ棨���ֶ����Ż���
    double **A = allocate_matrix(m, n);
    double **B = allocate_matrix(n, k);
    double **C = allocate_matrix(m, k);

    random_fill_matrix(A, m, n);
    random_fill_matrix(B, n, k);

    if (m <= 10 && n <= 10 && k <= 10) {
        print_matrix(A, m, n, "A");
        print_matrix(B, n, k, "B");
    }

    // ��ʼ���߳�
    pthread_t threads[MAX_THREADS];
    ThreadData thread_data[MAX_THREADS];

    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);

    for (int i = 0; i < num_threads; i++) {
        thread_data[i].m = m;
        thread_data[i].n = n;
        thread_data[i].k = k;
        thread_data[i].A = A;
        thread_data[i].B = B;
        thread_data[i].C = C;
        thread_data[i].thread_id = i;
        thread_data[i].num_threads = num_threads;
        pthread_create(&threads[i], NULL, matrix_multiply_thread, &thread_data[i]);
    }

    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }

    clock_gettime(CLOCK_MONOTONIC, &end);
    double time_spent = (end.tv_sec - start.tv_sec) + 
                       (end.tv_nsec - start.tv_nsec) / 1e9;

    if (m <= 10 && n <= 10 && k <= 10) {
        print_matrix(C, m, k, "C (Result)");
    }

    printf("\nMatrix %dx%d * %dx%d with %d threads\n", m, n, n, k, num_threads);
    printf("Time: %.6f seconds\n", time_spent);

    free_matrix(A, m);
    free_matrix(B, n);
    free_matrix(C, m);
    return 0;
}
