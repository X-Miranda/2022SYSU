#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <sched.h>
#include <unistd.h>
#include <math.h>

#define MAX_THREADS 16
#define BLOCK_SIZE 64  // ����CPU���������L1 Cacheͨ��Ϊ32-64KB��

typedef struct {
    int m, n, k;
    double **A, **B, **C;
    int thread_id;
    int num_threads;
    pthread_mutex_t *mutex;
    int *next_block;
} ThreadData;

void *matrix_multiply_thread(void *arg) {
    ThreadData *data = (ThreadData *)arg;
    
    // �����߳��׺��ԣ��󶨵��ض�CPU���ģ�
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(data->thread_id % sysconf(_SC_NPROCESSORS_ONLN), &cpuset);
    pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpuset);

    int blocks_per_dim = (int)ceil((double)data->m / BLOCK_SIZE);
    int total_blocks = blocks_per_dim * blocks_per_dim;
    
    while (1) {
        int block_idx;
        
        // ��̬��ȡ����飨���ٸ��ز����⣩
        pthread_mutex_lock(data->mutex);
        block_idx = (*data->next_block)++;
        pthread_mutex_unlock(data->mutex);
        
        if (block_idx >= total_blocks) break;
        
        int block_row = block_idx / blocks_per_dim;
        int block_col = block_idx % blocks_per_dim;
        
        int start_i = block_row * BLOCK_SIZE;
        int end_i = (start_i + BLOCK_SIZE > data->m) ? data->m : start_i + BLOCK_SIZE;
        int start_j = block_col * BLOCK_SIZE;
        int end_j = (start_j + BLOCK_SIZE > data->k) ? data->k : start_j + BLOCK_SIZE;
        
        // �ֿ�������
        for (int i = start_i; i < end_i; i++) {
            for (int j = start_j; j < end_j; j++) {
                double sum = 0;
                // ѭ��չ�����ֶ��Ż���
                int l;
                for (l = 0; l < data->n - 4; l += 4) {
                    sum += data->A[i][l] * data->B[l][j];
                    sum += data->A[i][l+1] * data->B[l+1][j];
                    sum += data->A[i][l+2] * data->B[l+2][j];
                    sum += data->A[i][l+3] * data->B[l+3][j];
                }
                // ����ʣ��Ԫ��
                for (; l < data->n; l++) {
                    sum += data->A[i][l] * data->B[l][j];
                }
                data->C[i][j] = sum;
            }
        }
    }
    return NULL;
}

double **allocate_matrix(int rows, int cols) {
    double **matrix = (double **)malloc(rows * sizeof(double *));
    for (int i = 0; i < rows; i++) {
        posix_memalign((void **)&matrix[i], 64, cols * sizeof(double));  // 64�ֽڶ��루����α������
    }
    return matrix;
}

void free_matrix(double **matrix, int rows) {
    for (int i = 0; i < rows; i++) {
        free(matrix[i]);
    }
    free(matrix);
}

void random_fill_matrix(double **matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            matrix[i][j] = (double)rand() / RAND_MAX * 100.0;
        }
    }
}

void print_matrix(double **matrix, int rows, int cols, const char *name) {
    printf("Matrix %s (first 5x5):\n", name);
    for (int i = 0; i < fmin(5, rows); i++) {
        for (int j = 0; j < fmin(5, cols); j++) {
            printf("%8.2f ", matrix[i][j]);
        }
        printf("\n");
    }
}

int main(int argc, char *argv[]) {

    int m = atoi(argv[1]);
    int n = atoi(argv[2]);
    int k = atoi(argv[3]);
    int num_threads = atoi(argv[4]);

    // �������������������߳�����������ȶ��ģ�
    int num_cores = sysconf(_SC_NPROCESSORS_ONLN);
    if (num_threads > num_cores * 2) {
        printf("Warning: Thread count (%d) exceeds 2x physical cores (%d)\n", 
               num_threads, num_cores);
    }

    srand(time(NULL));

    // �����ڴ棨�����Ż���
    double **A = allocate_matrix(m, n);
    double **B = allocate_matrix(n, k);
    double **C = allocate_matrix(m, k);

    random_fill_matrix(A, m, n);
    random_fill_matrix(B, n, k);

    if (m <= 10 && n <= 10 && k <= 10) {
        print_matrix(A, m, n, "A");
        print_matrix(B, n, k, "B");
    }

    // ��ʼ���߳�����
    pthread_t threads[MAX_THREADS];
    ThreadData thread_data[MAX_THREADS];
    pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
    int next_block = 0;

    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);

    for (int i = 0; i < num_threads; i++) {
        thread_data[i].m = m;
        thread_data[i].n = n;
        thread_data[i].k = k;
        thread_data[i].A = A;
        thread_data[i].B = B;
        thread_data[i].C = C;
        thread_data[i].thread_id = i;
        thread_data[i].num_threads = num_threads;
        thread_data[i].mutex = &mutex;
        thread_data[i].next_block = &next_block;
        pthread_create(&threads[i], NULL, matrix_multiply_thread, &thread_data[i]);
    }

    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }

    clock_gettime(CLOCK_MONOTONIC, &end);
    double time_spent = (end.tv_sec - start.tv_sec) + 
                       (end.tv_nsec - start.tv_nsec) / 1e9;

    if (m <= 10 && n <= 10 && k <= 10) {
        print_matrix(C, m, k, "C (Result)");
    }

    printf("\nMatrix %dx%d * %dx%d with %d threads\n", m, n, n, k, num_threads);
    printf("Time: %.6f seconds\n", time_spent);

    free_matrix(A, m);
    free_matrix(B, n);
    free_matrix(C, m);
    return 0;
}
