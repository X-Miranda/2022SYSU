#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <sched.h>
#include <unistd.h>

#define MAX_THREADS 16
#define CACHE_LINE_SIZE 64

typedef struct {
    int *array;
    long long sum __attribute__((aligned(CACHE_LINE_SIZE)));
    int start;
    int end;
    int thread_id;  
} ThreadData;

void *array_sum_thread(void *arg) {
    ThreadData *data = (ThreadData *)arg;
    
    // �����߳��׺���
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(data->thread_id % sysconf(_SC_NPROCESSORS_ONLN), &cpuset);
    pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpuset);

    long long local_sum = 0;
    const int stride = 8;  // ѭ��չ������
    
    // ��ѭ����չ��8�Σ�
    int i = data->start;
    for (; i <= data->end - stride; i += stride) {
        local_sum += data->array[i] + data->array[i+1] + 
                    data->array[i+2] + data->array[i+3] +
                    data->array[i+4] + data->array[i+5] +
                    data->array[i+6] + data->array[i+7];
    }
    
    // ����ʣ��Ԫ��
    for (; i < data->end; i++) {
        local_sum += data->array[i];
    }
    
    data->sum = local_sum;
    return NULL;
}

int main(int argc, char *argv[]) {
	
    int n = atoi(argv[1]);
    int num_threads = atoi(argv[2]);

    // �������������������߳���
    int num_cores = sysconf(_SC_NPROCESSORS_ONLN);
    if (num_threads > num_cores * 2) {
        printf("Warning: Reducing threads from %d to %d (2x physical cores)\n",
               num_threads, num_cores * 2);
        num_threads = num_cores * 2;
    }

    // �����ڴ棨�����Ż���
    int *array;
    posix_memalign((void**)&array, CACHE_LINE_SIZE, n * sizeof(int));
    
    // ��ʼ������
    for (int i = 0; i < n; i++) {
        array[i] = rand() % 100;
    }

    // �����߳�
    pthread_t threads[MAX_THREADS];
    ThreadData thread_data[MAX_THREADS] __attribute__((aligned(CACHE_LINE_SIZE)));
    int chunk_size = n / num_threads;
    
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);

    for (int i = 0; i < num_threads; i++) {
        thread_data[i].array = array;
        thread_data[i].start = i * chunk_size;
        thread_data[i].end = (i == num_threads - 1) ? n : (i + 1) * chunk_size;
        thread_data[i].thread_id = i;  // ����thread_id
        pthread_create(&threads[i], NULL, array_sum_thread, &thread_data[i]);
    }

    // �ȴ������߳�
    long long total_sum = 0;
    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
        total_sum += thread_data[i].sum;
    }

    clock_gettime(CLOCK_MONOTONIC, &end);
    double time_spent = (end.tv_sec - start.tv_sec) + 
                       (end.tv_nsec - start.tv_nsec) / 1e9;

    printf("Sum: %lld\n", total_sum);
    printf("Time: %.6f seconds\n", time_spent);

    free(array);
    return 0;
}
