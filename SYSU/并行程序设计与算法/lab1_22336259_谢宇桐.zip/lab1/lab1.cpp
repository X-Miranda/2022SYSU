#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <mpi.h>

#define MIN_SIZE 128
#define MAX_SIZE 2048

void initialize_matrix(double *matrix, int rows, int cols) {
    for (int i = 0; i < rows * cols; i++) {
        matrix[i] = (double)rand() / RAND_MAX;
    }
}

void print_matrix(double *matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%.2f ", matrix[i * cols + j]);
        }
        printf("\n");
    }
}

void sequential_matrix_multiply(double *A, double *B, double *C, int m, int n, int k) {
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < k; j++) {
            double sum = 0.0;
            for (int l = 0; l < n; l++) {
                sum += A[i * n + l] * B[l * k + j];
            }
            C[i * k + j] = sum;
        }
    }
}

void parallel_matrix_multiply(int rank, int size, double *A, double *B, double *C, int m, int n, int k) {
    int rows_per_process = m / size;
    int remaining_rows = m % size;
    
    double *local_A = (double *)malloc(rows_per_process * n * sizeof(double));
    double *local_C = (double *)malloc(rows_per_process * k * sizeof(double));
    
    MPI_Scatter(A, rows_per_process * n, MPI_DOUBLE, 
                local_A, rows_per_process * n, MPI_DOUBLE, 
                0, MPI_COMM_WORLD);
    
    MPI_Bcast(B, n * k, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    
    for (int i = 0; i < rows_per_process; i++) {
        for (int j = 0; j < k; j++) {
            double sum = 0.0;
            for (int l = 0; l < n; l++) {
                sum += local_A[i * n + l] * B[l * k + j];
            }
            local_C[i * k + j] = sum;
        }
    }
    
    MPI_Gather(local_C, rows_per_process * k, MPI_DOUBLE, 
               C, rows_per_process * k, MPI_DOUBLE, 
               0, MPI_COMM_WORLD);
    
    if (rank == 0 && remaining_rows > 0) {
        for (int i = m - remaining_rows; i < m; i++) {
            for (int j = 0; j < k; j++) {
                double sum = 0.0;
                for (int l = 0; l < n; l++) {
                    sum += A[i * n + l] * B[l * k + j];
                }
                C[i * k + j] = sum;
            }
        }
    }
    
    free(local_A);
    free(local_C);
}

int main(int argc, char *argv[]) {
    int rank, size;
    int m, n, k;
    double *A, *B, *C;
    double start_time, end_time;
    
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    
    if (rank == 0) {
        m = atoi(argv[1]);
        n = atoi(argv[2]);
        k = atoi(argv[3]);
        
        A = (double *)malloc(m * n * sizeof(double));
        B = (double *)malloc(n * k * sizeof(double));
        C = (double *)malloc(m * k * sizeof(double));
        
        srand(time(NULL));
        initialize_matrix(A, m, n);
        initialize_matrix(B, n, k);
        
        start_time = MPI_Wtime();
    }
    
    MPI_Bcast(&m, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&k, 1, MPI_INT, 0, MPI_COMM_WORLD);
    
    if (rank != 0) {
        B = (double *)malloc(n * k * sizeof(double));
    }
    
    parallel_matrix_multiply(rank, size, A, B, C, m, n, k);
    
    if (rank == 0) {
        end_time = MPI_Wtime();
        
        printf("Matrix A:\n");
        print_matrix(A, 5, 5); 
        printf("\nMatrix B:\n");
        print_matrix(B, 5, 5);
        printf("\nMatrix C (Result):\n");
        print_matrix(C, 5, 5);
        
        printf("\nTime taken: %.6f seconds\n", end_time - start_time);
        
        free(A);
        free(B);
        free(C);
    } else {
        free(B);
    }
    
    MPI_Finalize();
    return 0;
}
