# 项目说明

## 1.文件结构

```
--src1文件夹：论文一代码
--src2文件夹：论文二代码
--report：实验报告
```

## 2.论文一

### 配置

（1）Go 1.16.6或更高版本

（2）使用 apt-get 的 Install 命令：

```console
apt-get install golang-go
```

（3）安装软件包

```console
go get -u golang.org/x/crypto/...
go get -u github.com/dwkim606/test_lattigo
```

（4）python=3.10

（5）下载数据集：从链接下载数据文件 [https://drive.google.com/drive/folders/1zLTzJ58E_CDtqvnPv8t9YtgkDaHouWWn?usp=sharing](https://drive.google.com/drive/folders/1zLTzJ58E_CDtqvnPv8t9YtgkDaHouWWn?usp=sharing)，将所有文件夹（Resnet_enc_results、Resnet_plain_data、Resnet_weights test_conv_data）移动到与源代码相同的目录。

### 运行与测试

（1）卷积：对不同数量的批次运行 Baseline 和 Ours

- 参数（按输入顺序）：
  - conv
  - (3,5,7): 内核宽度
  - (0,1,2,3): 将批次数分别设置为 4、16、64、256。
  - (1 to 10):测试运行次数
- 示例命令：内核宽度为 3、批次数为 16 和 5 次测试运行的卷积

```console
go run *.go conv 3 1 5
```

（2）卷积后进行 ReLU 评估（和 Bootstrapping）：运行 Baseline 和 Ours

- 参数:
  - convReLU
  - 其他部分与 Convolutions 相同
- 示例命令：内核宽度为 5 的卷积，批次数为 4 和 3 次测试运行，然后使用 Bootstrapping 进行 ReLU 评估

```console
go run *.go convReLU 5 0 3
```

（3）使用该方法在 CIFAR10/CIFAR100 数据集上进行 20 层 CNN 评估

- 参数:
  - resnet
  - (3,5,7): 内核宽度
  - (8,14,20): CNN 的层数
  - (1,2,3): 广度系数
  - (1 to 100 or 1 to 1000): 测试次数
  - (true, false): true -> CIFAR100, false -> CIFAR10
- 可用参数列表:
  - resnet 3 20 1 (1 to 1000) (true/false)
  - resnet 5 20 1 (1 to 100) (true/false)
  - resnet 7 20 1 (1 to 100) (true/false)
  - resnet 5 8 3 (1 to 1000) (true/false)
  - resnet 3 14 3 (1 to 1000) (true/false)
  - resnet 3 20 3 (1 to 1000) (true/false)
- 示例命令：在 CIFAR10 数据集上的 10 个测试输入上运行内核宽度为 3、层数为 20、宽度因子为 1 的 CNN

```console
go run *.go resnet 3 20 1 10 false
```

（4）检查加密推理的精度：运行 `compare_final.py`

- 示例命令：检查内核 3、深度 20、widness 1 CNN 推理对 CIFAR10 数据集的精度

```console
python3 compare_final.py 3 20 1 false
```

注意 ：精度检查需要事先执行加密的推理。

## 3.论文二

### 配置

（1）模型下载：[Google Drive](https://drive.google.com/drive/folders/17vV8wySe9fMYi0vgGlHUhuWZtKpW59HC?usp=sharing)

（2）torch>=2.0.0, python>=3.10

（3）安装其他依赖：`pip install -r requirements.txt`

（4）准备数据集（同论文一）

### 运行与测试

（1）训练脚本：运行 CirILP.py 获取分块配置

此步骤加载预训练模型并生成分层块大小配置，脚本为 `ILP.sh`
示例（在CIFAR-10上配置ViT）：

```shell
CUDA_VISIBLE_DEVICES=1 python CirILP.py -c configs/datasets/ViT/cifar10_ILP.yml --model vit_7_4_32 CIFAR10路径
```

日志文件 `vit_c10_ILP.log` 将保存配置信息，关键参数：

* `budget`：可设为 2/4/8（对应时延低于均匀分块2/4/8的配置）
* `better_initialization`：True->使用PrivCirNet初始化法，False->使用传统 $\min |W'-W|_2^2$ 初始化

（2）训练循环矩阵模型

加载预训练模型，使用前述配置训练循环矩阵模型，脚本为 `train_cir.sh`。
示例（训练CIFAR-10上的ViT）：

```shell
CUDA_VISIBLE_DEVICES=1 python train_cir.py -c configs/datasets/ViT/cifar10_fix.yml --model vit_7_4_32 CIFAR10路径
```

关键参数：

* `fix_blocksize_list`：前步获取的分块配置（逗号分隔）
* `log_name`：日志文件名
* `use_kd`：是否使用知识蒸馏（需在yml指定教师模型）
* `initial_checkpoint`：原始模型初始检查点（[下载地址](https://drive.google.com/drive/folders/18R8JJ-FGkNd8m6TXdBcV52H0bM5LYkRr?usp=sharing)）

（3）其他基线模型训练

支持两种基线模型训练：

* **均匀分块循环网络** ：通过设置 `fix_blocksize=2/4/8` 训练
* **结构化剪枝(SpENCNN)** ：使用脚本 `train_prune.sh`
  示例（训练CIFAR-10上的MobileNetV2）：

```shell
CUDA_VISIBLE_DEVICES=1 python train_prune.py -c configs/datasets/Prune/cifar10.yml --model c10_prune_mobilenetv2 CIFAR10路径
```

  关键参数：

* `prune_ratio`：剪枝比例
* 预训练模型：[下载地址](https://drive.google.com/drive/folders/1tr-pDDPkFIpb_jCB267W3RUIqylCF0Jn?usp=sharing)

### 许可协议

本项目采用 MIT 许可证 - 详见 [LICENSE](https://license/) 文件
