import numpy as np
from sklearn.datasets import load_iris
from sklearn.metrics import accuracy_score, silhouette_score, calinski_harabasz_score
from sklearn.preprocessing import StandardScaler
from scipy.spatial.distance import cdist
from collections import Counter

# 加载鸢尾花数据集
iris = load_iris()
X = iris.data
y = iris.target

# 标准化数据
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# K-means算法
def kmeans(X, k, max_iters=100):
    centroids = X[np.random.choice(X.shape[0], k, replace=False)]
    for _ in range(max_iters):
        distances = cdist(X, centroids, metric='euclidean')
        labels = np.argmin(distances, axis=1)
        new_centroids = np.array([X[labels == i].mean(axis=0) for i in range(k)])
        if np.all(centroids == new_centroids):
            break
        centroids = new_centroids
    return labels, centroids

# DBSCAN算法
def dbscan(X, eps, min_samples):
    n_samples = X.shape[0]
    labels = -np.ones(n_samples)
    cluster_id = 0
    for i in range(n_samples):
        if labels[i] != -1:
            continue
        neighbors = np.where(cdist([X[i]], X, metric='euclidean')[0] <= eps)[0]
        if len(neighbors) < min_samples:
            labels[i] = -1
        else:
            labels[i] = cluster_id
            j = 0
            while j < len(neighbors):
                neighbor = neighbors[j]
                if labels[neighbor] == -1:
                    labels[neighbor] = cluster_id
                elif labels[neighbor] == -1:
                    labels[neighbor] = cluster_id
                    new_neighbors = np.where(cdist([X[neighbor]], X, metric='euclidean')[0] <= eps)[0]
                    if len(new_neighbors) >= min_samples:
                        neighbors = np.concatenate([neighbors, new_neighbors])
                j += 1
            cluster_id += 1
    return labels

# 匹配标签
def match_labels(true_labels, cluster_labels):
    matched_labels = np.zeros_like(cluster_labels)
    for cluster in np.unique(cluster_labels):
        mask = (cluster_labels == cluster)
        true_label = Counter(true_labels[mask]).most_common(1)[0][0]
        matched_labels[mask] = true_label
    return matched_labels

# 调整超参数
k_values = [2, 3, 4, 5, 6, 7, 8, 9]
for k in k_values:
    labels, _ = kmeans(X_scaled, k)
    accuracy = accuracy_score(y, match_labels(y, labels))
    silhouette = silhouette_score(X_scaled, labels)
    ch_score = calinski_harabasz_score(X_scaled, labels)
    print(f"K-means with k={k}: Accuracy={accuracy:.4f}, Silhouette={silhouette:.4f}, CH Index={ch_score:.4f}")

eps_values = [0.3, 0.5, 0.7]
min_samples_values = [3, 5, 7]
for eps in eps_values:
    for min_samples in min_samples_values:
        labels = dbscan(X_scaled, eps, min_samples)
        if len(np.unique(labels)) > 1:
            accuracy = accuracy_score(y, match_labels(y, labels))
            silhouette = silhouette_score(X_scaled, labels)
            ch_score = calinski_harabasz_score(X_scaled, labels)
            print(f"DBSCAN with eps={eps}, min_samples={min_samples}: Accuracy={accuracy:.4f}, Silhouette={silhouette:.4f}, CH Index={ch_score:.4f}")
