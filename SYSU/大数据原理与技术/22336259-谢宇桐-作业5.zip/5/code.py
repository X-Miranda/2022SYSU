# Install dependencies as needed:
# pip install kagglehub[pandas-datasets]
import kagglehub
from kagglehub import KaggleDatasetAdapter
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler

# 加载数据并筛选2020-2024年
df = pd.read_csv("/kaggle/input/alibaba-stock-dataset-2025/Ali_Baba_Stock_Data.csv")
df['Date'] = pd.to_datetime(df['Date'])
df = df[(df['Date'] >= '2020-01-01') & (df['Date'] <= '2025-1-30')]
df = df.set_index('Date').sort_index()

# 使用调整后收盘价（Adj Close）
data = df[['Adj Close']].rename(columns={'Adj Close': 'close'})

# 数据标准化（LSTM）
scaler = MinMaxScaler(feature_range=(0, 1))
scaled_data = scaler.fit_transform(data)


# 可视化
plt.figure(figsize=(12, 6))
plt.plot(data.index, data['close'])
plt.title('Alibaba Stock Price (2020-2024)')
plt.xlabel('Date')
plt.ylabel('Adjusted Close Price ($)')
plt.grid()
plt.show()

from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_absolute_error, mean_squared_error
import math

# 拆分数据集
train_size = int(len(data) * 0.8)
train, test = data.iloc[:train_size], data.iloc[train_size:]

# 拟合ARIMA模型（通过ADF测试确定d=1，ACF/PACF确定p=5,q=0）
model = ARIMA(train['close'], order=(5, 1, 0))
model_fit = model.fit()

# 预测未来7天
forecast_steps = 7
forecast = model_fit.forecast(steps=forecast_steps)

# 计算指标
actual = test['close'].iloc[:forecast_steps]
mae_arima = mean_absolute_error(actual, forecast)
rmse_arima = math.sqrt(mean_squared_error(actual, forecast))

# 可视化结果
plt.figure(figsize=(12, 6))
plt.plot(train.index[-60:], train['close'].iloc[-60:], label='Training Data')
plt.plot(test.index[:forecast_steps], actual, label='Actual Price')
plt.plot(test.index[:forecast_steps], forecast, label='ARIMA Forecast', linestyle='--', marker='o')
plt.title('Alibaba Stock Price Prediction (ARIMA)')
plt.xlabel('Date')
plt.ylabel('Price ($)')
plt.legend()
plt.grid()
plt.show()

print(f"ARIMA 性能指标: MAE={mae_arima:.2f}, RMSE={rmse_arima:.2f}")

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping


def create_dataset(data, time_steps=60):
    X, y = [], []
    for i in range(time_steps, len(data)):
        X.append(data[i-time_steps:i, 0])  # 提取时间序列特征
        y.append(data[i, 0])  # 提取目标值
    X = np.array(X)
    y = np.array(y)
    X = X.reshape((X.shape[0], X.shape[1], 1))  # 调整形状为 (samples, time_steps, features)
    return X, y

time_steps = 60
X, y = create_dataset(scaled_data, time_steps)
train_size = int(len(X) * 0.8)
X_train, X_test = X[:train_size], X[train_size:]
y_train, y_test = y[:train_size], y[train_size:]

model = Sequential([
    LSTM(100, return_sequences=True, input_shape=(time_steps, 1)),
    Dropout(0.2),
    LSTM(100),
    Dropout(0.2),
    Dense(1)
])
model.compile(optimizer='adam', loss='mse')

history = model.fit(
    X_train, y_train,
    epochs=50,
    batch_size=32,
    validation_data=(X_test, y_test),
    callbacks=[EarlyStopping(patience=5)],
    verbose=1
)

# 预测未来7天
def forecast_next_days(model, last_sequence, steps=7):
    forecast = []
    current_seq = last_sequence[-time_steps:]
    for _ in range(steps):
        pred = model.predict(current_seq.reshape(1, time_steps, 1))[0, 0]
        forecast.append(pred)
        current_seq = np.append(current_seq[1:], pred).reshape(-1, 1)
    return scaler.inverse_transform(np.array(forecast).reshape(-1, 1))

# 预测未来7天
last_sequence = scaled_data[-time_steps:]  # 获取最后60天的数据作为初始序列
lstm_pred = forecast_next_days(model, last_sequence, steps=7)  # 正确调用

# 生成未来7天的日期
forecast_dates = pd.date_range(
    start=data.index[-1],
    periods=8,          # 生成8个点（包含起始日+7天）
    inclusive='right'   # 排除起始日，保留后7天
)[1:]  # 或者直接 periods=7, inclusive='neither'


# 评估和绘制测试集结果
test_pred = model.predict(X_test)
test_pred = scaler.inverse_transform(test_pred)
actual_prices = scaler.inverse_transform(y_test.reshape(-1, 1))
lstm_mae = mean_absolute_error(actual_prices, test_pred)
lstm_rmse = math.sqrt(mean_squared_error(actual_prices, test_pred))

# 绘制代码：
plt.figure(figsize=(12, 6))

# 绘制历史数据
plt.plot(data.index[-100:], data['close'][-100:], label='Actual', color='blue')

# 绘制测试集预测
test_dates = data.index[train_size+time_steps:]
plt.plot(test_dates, test_pred, label='Test Predictions', color='green', alpha=0.7)

# 绘制未来预测
forecast_dates = pd.date_range(start=data.index[-1], periods=8, inclusive='right')
plt.plot(forecast_dates, lstm_pred, label='7-Day Forecast', color='red', marker='o')

plt.title('Stock Price Prediction with LSTM')
plt.xlabel('Date')
plt.ylabel('Price')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

print(f"LSTM MAE: {lstm_mae:.2f}, RMSE: {lstm_rmse:.2f}")