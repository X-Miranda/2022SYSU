import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity, linear_kernel
from sklearn.model_selection import train_test_split
from scipy.sparse import csr_matrix
from collections import defaultdict
import time

# 1. 数据加载与预处理优化
def load_data():
    movies = pd.read_csv('./ml-latest-small/ml-latest-small/movies.csv')
    ratings = pd.read_csv('./ml-latest-small/ml-latest-small/ratings.csv')
    tags = pd.read_csv('./ml-latest-small/ml-latest-small/tags.csv')

    # 合并标签数据
    movie_tags = tags.groupby('movieId')['tag'].apply(lambda x: '|'.join(x)).reset_index()
    movie_tags.columns = ['movieId', 'tags']
    movies = movies.merge(movie_tags, on='movieId', how='left')
    movies['tags'] = movies['tags'].fillna('')

    # 优化内容特征
    movies['content'] = movies['genres'].str.replace('|', ' ') + ' ' + movies['tags'].str.replace('|', ' ')

    return movies, ratings

movies, ratings = load_data()

# 2. 基于内容的推荐优化
def build_content_model():
    # 增加特征维度
    tfidf = TfidfVectorizer(stop_words='english', max_features=10000)
    tfidf_matrix = tfidf.fit_transform(movies['content'])
    content_sim = linear_kernel(tfidf_matrix, tfidf_matrix)
    return content_sim

content_sim = build_content_model()

def content_based_recommendations(movie_id, top_n=10):
    try:
        idx = movies[movies['movieId'] == movie_id].index[0]
        sim_scores = list(enumerate(content_sim[idx]))
        sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
        movie_indices = [i[0] for i in sim_scores[1:top_n + 1]]
        return movies.iloc[movie_indices]['movieId'].tolist()
    except:
        return []

# 3. 协同过滤推荐优化
def build_cf_models():
    # 创建稀疏矩阵节省内存
    user_movie_matrix = ratings.pivot_table(
        index='userId',
        columns='movieId',
        values='rating',
        fill_value=0
    )
    movie_user_matrix = user_movie_matrix.T

    # 只计算前200个相似用户/物品以提高性能
    user_sim = cosine_similarity(user_movie_matrix)[:, :200]
    item_sim = cosine_similarity(movie_user_matrix)[:, :200]

    return user_movie_matrix, user_sim, item_sim

user_movie_matrix, user_sim, item_sim = build_cf_models()

def user_based_recommendations(user_id, top_n=10):
    try:
        user_idx = user_movie_matrix.index.get_loc(user_id)
        sim_users = user_sim[user_idx]

        # 获取相似用户的加权推荐
        recommendations = defaultdict(float)
        for sim_user_idx, score in enumerate(sim_users):
            if score > 0.2:  # 降低相似度阈值
                liked_movies = ratings[
                    (ratings['userId'] == user_movie_matrix.index[sim_user_idx]) &
                    (ratings['rating'] > 3.5)]
                for movie_id in liked_movies['movieId']:
                    recommendations[movie_id] += score

        # 排除已评价的电影
        user_rated = ratings[ratings['userId'] == user_id]['movieId'].tolist()
        recommendations = {k: v for k, v in recommendations.items() if k not in user_rated}

        return sorted(recommendations, key=recommendations.get, reverse=True)[:top_n]
    except:
        return []

def item_based_recommendations(movie_id, top_n=10):
    try:
        movie_idx = user_movie_matrix.columns.get_loc(movie_id)
        sim_items = item_sim[movie_idx]

        # 获取相似物品的加权推荐
        recommendations = defaultdict(float)
        # 降低相似度阈值
        for sim_movie_idx, score in enumerate(sim_items):
            if score > 0.2:
                sim_movie_id = user_movie_matrix.columns[sim_movie_idx]
                recommendations[sim_movie_id] += score

        return sorted(recommendations, key=recommendations.get, reverse=True)[:top_n]
    except:
        return []

# 4. 评估方法优化
def evaluate_recall(test_ratings, recommendation_fn, user_based=True, sample_users=50):
    hits = 0
    total = 0

    # 抽样部分用户提高评估速度
    user_sample = np.random.choice(test_ratings['userId'].unique(),
                                   min(sample_users, len(test_ratings['userId'].unique())),
                                   replace=False)

    for user_id in user_sample:
        actual = set(test_ratings[
                         (test_ratings['userId'] == user_id) &
                         (test_ratings['rating'] > 3.5)
                         ]['movieId'])

        if not actual:
            continue

        if user_based:
            recommended = set(recommendation_fn(user_id))
        else:
            user_liked = ratings[
                (ratings['userId'] == user_id) &
                (ratings['rating'] > 3.5)]
            if user_liked.empty:
                continue
            recommended = set()
            for movie_id in user_liked['movieId'].sample(min(3, len(user_liked))):
                recommended.update(recommendation_fn(movie_id))

        hits += len(actual & recommended)
        total += len(actual)

    return hits / total if total > 0 else 0

# 5. 混合推荐优化
def hybrid_recommendation(user_id, top_n=10, weights=(0.1, 0.6, 0.3)):
    alpha, beta, gamma = weights

    # 并行获取推荐结果
    user_rec = user_based_recommendations(user_id, top_n * 3)
    item_rec = []
    content_rec = []

    user_liked = ratings[
        (ratings['userId'] == user_id) &
        (ratings['rating'] > 3.5)
        ]['movieId'].sample(min(5, len(ratings)))  # 限制使用的喜欢电影数量

    for movie_id in user_liked:
        item_rec.extend(item_based_recommendations(movie_id, top_n // 2))
        content_rec.extend(content_based_recommendations(movie_id, top_n // 2))

    # 合并推荐结果
    recommendations = defaultdict(float)

    for i, movie_id in enumerate(user_rec):
        recommendations[movie_id] += alpha * (1 - i / len(user_rec))

    for i, movie_id in enumerate(item_rec):
        recommendations[movie_id] += beta * (1 - i / len(item_rec))

    for i, movie_id in enumerate(content_rec):
        recommendations[movie_id] += gamma * (1 - i / len(content_rec))

    return sorted(recommendations, key=recommendations.get, reverse=True)[:top_n]

# 6. 评估流程优化
def evaluate_models():
    # 划分训练测试集时确保每个用户都有数据，减少测试集比例
    train, test = train_test_split(ratings, test_size=0.1, random_state=42,
                                   stratify=ratings['userId'])

    print("Evaluating models...")

    start = time.time()
    user_recall = evaluate_recall(test, user_based_recommendations, user_based=True)
    print(f"User-Based CF Recall: {user_recall:.4f} (Time: {time.time() - start:.2f}s)")

    start = time.time()
    item_recall = evaluate_recall(test, item_based_recommendations, user_based=False)
    print(f"Item-Based CF Recall: {item_recall:.4f} (Time: {time.time() - start:.2f}s)")

    start = time.time()
    content_recall = evaluate_recall(test, content_based_recommendations, user_based=False)
    print(f"Content-Based Recall: {content_recall:.4f} (Time: {time.time() - start:.2f}s)")

    start = time.time()
    hybrid_recall = evaluate_recall(test, hybrid_recommendation, user_based=True)
    print(f"Hybrid Recommendation Recall: {hybrid_recall:.4f} (Time: {time.time() - start:.2f}s)")

evaluate_models()