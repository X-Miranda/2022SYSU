import numpy as np
import time
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.datasets import fetch_openml
from sklearn.preprocessing import StandardScaler

# 加载MNIST数据集
mnist = fetch_openml('mnist_784', version=1)
X, y = mnist["data"], mnist["target"].astype(int)

# 归一化到[0,1]
X = X / 255.0

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=56)

# 训练随机森林（去掉PCA）
rf = RandomForestClassifier(n_estimators=500, max_depth=20, random_state=56)
start_time = time.time()
rf.fit(X_train, y_train)
rf_train_time = time.time() - start_time

# 评估随机森林
rf_pred = rf.predict(X_test)
rf_acc = accuracy_score(y_test, rf_pred)
print(f"Random Forest Accuracy: {rf_acc:.4f}, Training Time: {rf_train_time:.2f}s")

# 标准化数据（仅用于MLP）
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 训练MLP
mlp = MLPClassifier(hidden_layer_sizes=(256,), max_iter=100, random_state=56)
start_time = time.time()
mlp.fit(X_train_scaled, y_train)
mlp_train_time = time.time() - start_time

# 评估MLP
mlp_pred = mlp.predict(X_test_scaled)
mlp_acc = accuracy_score(y_test, mlp_pred)
print(f"MLP Accuracy: {mlp_acc:.4f}, Training Time: {mlp_train_time:.2f}s")