import cv2
import matplotlib.pyplot as plt

# 读取图像
image = cv2.imread('./rigui.jpg')
if image is None:
    raise FileNotFoundError("图片未找到，请检查路径是否正确")

# 预处理
# 灰度化，将BGR彩色图转为单通道灰度图
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
# 高斯模糊，消除高频噪声。(3, 3)：高斯核大小，必须是奇数  0：标准差
gray = cv2.GaussianBlur(gray, (9, 9), 0)

# Sobel边缘检测
sobel_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
sobel_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
# 转换数据类型，从64位浮点转为8位无符号整数
abs_sobel_x = cv2.convertScaleAbs(sobel_x)
abs_sobel_y = cv2.convertScaleAbs(sobel_y)
# 梯度合成
sobel_combined = cv2.addWeighted(abs_sobel_x, 0.5, abs_sobel_y, 0.5, 0)

# 反转颜色并调整对比度
sobel_inverted = 255 - sobel_combined  # 颜色反转
adjusted = cv2.convertScaleAbs(sobel_inverted, alpha=0.5, beta=127.5)  # 调整参数

# 可视化
plt.figure(figsize=(12, 6))

plt.subplot(1, 2, 1)
plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
plt.title('Original Image')
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(adjusted, cmap='gray')
plt.title('White Background with Gray Edges')
plt.axis('off')

plt.tight_layout()
plt.show()