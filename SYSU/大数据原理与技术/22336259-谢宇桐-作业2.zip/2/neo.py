import spacy
from neo4j import GraphDatabase

# 加载 spaCy 的预训练模型
nlp = spacy.load("en_core_web_trf")

# 从文件中加载文本
def load_text_from_file(file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        text = file.read()
    return text

# 使用 spaCy 提取实体和关系
def extract_entities_and_relations(text):
    doc = nlp(text)

    # 提取实体
    entities = [(ent.text, ent.label_) for ent in doc.ents]

    # 提取关系
    relations = []
    for token in doc:
        if token.dep_ in ("nsubj", "dobj", "pobj"):  # 提取主语、宾语等关系
            relations.append((token.head.text, token.dep_, token.text))

    return entities, relations

# 构建 Neo4j 知识图谱
def create_graph(uri, user, password, entities, relations):
    # 连接到 Neo4j 数据库
    driver = GraphDatabase.driver(uri, auth=(user, password))

    with driver.session() as session:
        # 创建实体节点
        for entity in entities:
            if entity[1] == "PERSON":
                session.run("MERGE (n:Person {name: $name})", name=entity[0])
            elif entity[1] == "WORK_OF_ART":
                session.run("MERGE (n:Movie {title: $title})", title=entity[0])

        # 创建关系
        for relation in relations:
            head, dep, tail = relation
            if dep == "nsubj":
                session.run(
                    "MATCH (a:Movie {title: $title}), (b:Person {name: $name}) "
                    "MERGE (a)<-[r:ACTED_IN]-(b)",
                    title=head, name=tail,
                )
            elif dep == "dobj":
                session.run(
                    "MATCH (a:Person {name: $name}), (b:Movie {title: $title}) "
                    "MERGE (a)-[r:DIRECTED]->(b)",
                    name=head, title=tail,
                )

    # 关闭连接
    driver.close()

# Step 5: 主函数
def main():
    # 加载文本文件
    file_path = ".\data.txt"  # 确保文件路径正确
    text = load_text_from_file(file_path)

    # 提取实体和关系
    entities, relations = extract_entities_and_relations(text)
    print("Extracted Entities:", entities)
    print("Extracted Relations:", relations)

    # Neo4j 连接信息
    uri = "bolt://localhost:7687"
    user = "neo4j"
    password = "040601089"  # 替换为你的 Neo4j 密码

    # 构建知识图谱
    print("Start constructing graph...")
    create_graph(uri, user, password, entities, relations)
    print("All done!")

if __name__ == "__main__":
    main()