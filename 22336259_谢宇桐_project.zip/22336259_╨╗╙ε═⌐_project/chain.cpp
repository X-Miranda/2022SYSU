#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
using namespace std;
#include<map>
#include<fstream>
#include<stdio.h>
#include<string>
#include <cstdio>
#include<stdlib.h>
#include <vector>
#include <list>

int TABLE_SIZE = 3567;

struct node{
	string word;
	string chinese;
	node(string& a,string& b):word(a),chinese(b){
	}
};

class table{
	private:
		vector<list<node> > h;
		
	public:
		table() : h(TABLE_SIZE) {}
		int probes = 1;
    // ��ϣ����
    
int hashFunction(string english){
        char *q = &english[0];
        int seed = 31;
        long long int index = 0;
        while(*q){
           index = index * seed + *q;
            q++;
        }
        int result = abs(index) % TABLE_SIZE;
        return result;
}
    // �����ֵ��
    	void insert(string a,string b) {
        	int i = hashFunction(a);
        	h[i].emplace_back(a, b);
    	}

    // ���Ҽ���Ӧ��ֵ
    string get(string a) {
        int i = hashFunction(a);
        for (auto& n : h[i]) {
        	probes++;
            if (n.word == a) {
                return n.chinese;
            }
            
        }
        return ""; // ��ʾδ�ҵ�
    }

    // ɾ����ֵ��
   /* void remove(const string a) {
        int i = hashFunction(a);
        table[i].remove_if([key](const node& n) { return node.key == key; });
    }*/
};



 
int main()
{
	char str[100] = { 0 };
	char str1[50] = { 0 };
	char str2[50] = { 0 };
	string tmp1;
	string tmp2;
	string eng;
	//���ļ�
	fstream filestr;
	filestr.open("./dict.txt", fstream::in );
	
	//����һ��map�����
	table H;
	string it;
	while (filestr.peek()!=EOF)
	{
		filestr.getline(str, 100);
		sscanf(str, "%s %s", str1, str2);
		tmp1 = str1;
		tmp2 = str2;
		H.insert(tmp1,tmp2);

	}
//	cout << "�ļ��е��ַ�����" << H.size() << endl;
	int num;
	cin >> num;
	while (num--){
		cin >> eng;
		//c_str():��string����ת��Ϊchar 
		//if (strcmp(eng.c_str(), "q") == 0)
		//{
		//	break;
		//}
		//��������ֱ�ӱȽ�
		if (eng == "q")
		{
			break;
		}
		it = H.get(eng);
		if (it == "")
		{
			cout << ": Not exist." << endl;
		}
		else
		{
			cout <<  ": " << it << endl;
		}
	}
 	cout << H.probes<< endl;
	//�ر��ļ�
	filestr.close();
	return 0;
}
