#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
using namespace std;
#include<map>
#include<fstream>
#include<string>
#include<stdlib.h>
#include <vector>

int TABLE_SIZE = 32100;
struct Pair {
    string word;
    string chinese;
	Pair(){
	}
    Pair(string& a, string& b) : word(a), chinese(b) {}
};

class Linear{
private:
    vector<Pair> table;
    vector<bool> occupied;


public:
    Linear() : table(TABLE_SIZE), occupied(TABLE_SIZE, false) {
    
	}
    // ��ϣ���� 
    int hashFunction(string english){
        char *q = &english[0];
        int seed = 31;
        long long int index = 0;
        while(*q){
           index = index * seed + *q;
            q++;
        }
        int result = abs(index) % TABLE_SIZE;
        return result;
}

    // �����ֵ��// ����̽��
    void linsert(string& a, string& b) {
        int i = hashFunction(a);

        
        while (occupied[i]) {
            i = (i + 1) % TABLE_SIZE;
        }

        table[i] = Pair(a, b);
        occupied[i] = true;
    }
    
    
    // ����̽��
    
    	void qur_insert(string a,string b){
			int index=hashFunction(a);
			int i=1;
		while(occupied[index]){
			index=(index+i*i)%TABLE_SIZE;
			i++;
		}
		table[index] = Pair(a, b);
		occupied[index] = true;
	}
	int probes=1;
    // ���Ҽ���Ӧ��ֵ
    string get(string& a) {
        int i = hashFunction(a);

        while (occupied[i]) {
        	probes++;
        	if(table[i].word != a){
        		i = (i + 1) % TABLE_SIZE;
			}
            else break;
        }
        //probes++;
        if (occupied[i]) {
        	
            return table[i].chinese;
        } 
		else {
            return ""; // ��ʾδ�ҵ�
        }
    }
};

 

 
 
 
int main()
{
	char str[100] = { 0 };
	char str1[50] = { 0 };
	char str2[50] = { 0 };
	string tmp1;
	string tmp2;
	string eng;
	//���ļ�
	fstream filestr;
	filestr.open("dict.txt", fstream::in );
	
	//����һ��map�����
	Linear H;

	string it;
	while (filestr.peek()!=EOF){
		filestr.getline(str, 100);
		sscanf(str, "%s %s", str1, str2);
		tmp1 = str1;
		tmp2 = str2;
		H.qur_insert(tmp1,tmp2);
	}
//	ifstream infile;
//	infile.open("successful.txt");
	//infile.open("unsuccessful.txt"); 
	//cout << "�ļ��е��ַ�����" << dictmap.size() << endl;
	int num;
	cin >> num;
	while (num--){
		string eng;
		cin >> eng;
		//c_str():��string����ת��Ϊchar 
		//if (strcmp(eng.c_str(), "q") == 0)
		//{
		//	break;
		//}
		//��������ֱ�ӱȽ�
		it = H.get(eng);
		if (it == "")
		{
			cout << ": Not exist." << endl;
		}
		else
		{	
			
			cout <<  ": " << it << endl;
		}
		
	}
 	cout << H.probes<< endl;
	//�ر��ļ�
	filestr.close();
//	infile.close();
	return 0;
}
